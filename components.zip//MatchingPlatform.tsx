import { useState, useMemo } from "react";
import { ArrowLeft, Moon, Sun, AlertCircle, CheckCircle, Clock, ChevronUp, ChevronDown, X, CheckSquare, XCircle, ChevronRight } from "lucide-react";
import { Breadcrumb } from "./Breadcrumb";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { PotentialMatchesTable } from "./PotentialMatchesTable";

export interface MediaArticleMatch {
  id: string;
  title: string;
  source: string;
  sourceType: string;
  matchedCbsArticle: string;
  confidenceScore: number;
  verificationStatus: "pending" | "verified" | "corrected" | "deferred" | "closed";
  date: string;
  cbsArticleDate?: string; // CBS publication date
  fullText: string;
  keyTerms: string[];
  cbsCategory: string;
  snippet: string;
  content: string;
  link: string;
  page?: string;
  edition?: string;
}

interface MatchingPlatformProps {
  onBack: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onSelectArticle: (article: MediaArticleMatch) => void;
  onMediaArticleClick?: (article: any) => void;
  onCbsArticleClick?: (cbsArticleTitle: string) => void;
  articles: MediaArticleMatch[];
  hideHeader?: boolean;
  activeFilter?: "potentialMatches" | "orphans" | "deferred" | "errors" | "closed";
  onClearFilter?: () => void;
  pageTitle?: string;
  onBulkVerify?: (cbsArticle: string, articleIds: string[]) => void;
}

export function MatchingPlatform({ 
  onBack, 
  isDarkMode, 
  onToggleDarkMode, 
  onSelectArticle, 
  onMediaArticleClick, 
  onCbsArticleClick, 
  articles,
  hideHeader = false,
  activeFilter = "potentialMatches",
  onClearFilter,
  pageTitle,
  onBulkVerify
}: MatchingPlatformProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStatus, setSelectedStatus] = useState<"all" | "verified" | "unverified">("all");
  const [sortBy, setSortBy] = useState<"mediaDate" | "cbsDate" | "confidence" | "status">("mediaDate");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const [selectedCount, setSelectedCount] = useState(0);
  const [verifyHandler, setVerifyHandler] = useState<(() => void) | null>(null);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Arbeid en inkomen":
        return "bg-[#0580a1] text-white";
      case "Economie":
        return "bg-[#271D6C] text-white";
      case "Maatschappij":
        return "bg-[#af0e80] text-white";
      case "Bouwen en wonen":
        return "bg-[#f39200] text-white";
      default:
        return "bg-gray-200 text-gray-800";
    }
  };

  const handleSort = (column: "mediaDate" | "cbsDate" | "confidence" | "status") => {
    if (sortBy === column) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(column);
      setSortOrder("desc");
    }
  };

  const filteredAndSortedArticles = articles
    .filter(article => {
      // Status filter - "unverified" should match both "pending" and "corrected"
      if (selectedStatus === "verified" && article.verificationStatus !== "verified") return false;
      if (selectedStatus === "unverified" && article.verificationStatus === "verified") return false;
      if (searchQuery && !article.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      return true;
    })
    .sort((a, b) => {
      let comparison = 0;
      if (sortBy === "confidence") {
        comparison = a.confidenceScore - b.confidenceScore;
      } else if (sortBy === "mediaDate") {
        comparison = new Date(a.date).getTime() - new Date(b.date).getTime();
      } else if (sortBy === "cbsDate") {
        const dateA = a.cbsArticleDate ? new Date(a.cbsArticleDate).getTime() : 0;
        const dateB = b.cbsArticleDate ? new Date(b.cbsArticleDate).getTime() : 0;
        comparison = dateA - dateB;
      } else if (sortBy === "status") {
        const statusOrder = { verified: 0, corrected: 1, pending: 2, deferred: 3, closed: 4 };
        comparison = statusOrder[a.verificationStatus] - statusOrder[b.verificationStatus];
      }
      return sortOrder === "asc" ? comparison : -comparison;
    });

  const verifiedCount = articles.filter(a => a.verificationStatus === "verified").length;
  const unverifiedCount = articles.filter(a => a.verificationStatus !== "verified").length;

  const getFilterLabel = () => {
    if (activeFilter === "potentialMatches") return "Potentiele matches";
    if (activeFilter === "orphans") return "Weeskinderen";
    if (activeFilter === "deferred") return "Uitgestelde kinderen";
    if (activeFilter === "errors") return "Error matches";
    if (activeFilter === "closed") return "Gesloten kinderen";
    return null;
  };

  if (hideHeader) {
    // Embedded version for dashboard
    return (
      <Card className={`border-2 w-full h-full flex flex-col overflow-hidden rounded ${isDarkMode ? 'bg-gray-800 border-gray-700' : ''}`}>
        {/* Header */}
        <div className="flex items-center justify-between px-5 h-10 rounded-t" style={{ backgroundColor: '#0580a1' }}>
          <h3 className="text-white mb-0 text-base">Potentiele matches</h3>
          <div className="flex items-center gap-2">
            {/* Verify button for potential matches */}
            {activeFilter === "potentialMatches" && selectedCount > 0 && (
              <button
                onClick={() => verifyHandler?.()}
                className="inline-flex items-center gap-2 px-3 py-1.5 bg-white text-[#0580a1] rounded text-sm font-medium hover:bg-gray-100 transition-colors"
              >
                <CheckSquare className="w-4 h-4" />
                Geselecteerde verifiëren ({selectedCount})
              </button>
            )}
            {activeFilter !== "potentialMatches" && getFilterLabel() && (
              <>
                <span className="text-sm text-white">
                  Filter: {getFilterLabel()}
                </span>
                <button
                  onClick={onClearFilter}
                  className="p-1 rounded transition-colors hover:bg-[#005470]"
                  title="Verwijder filter"
                >
                  <X className="w-4 h-4 text-white" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Render parent-child table for Potentiele matches, regular table for others */}
        {activeFilter === "potentialMatches" ? (
          <PotentialMatchesTable
            articles={filteredAndSortedArticles}
            isDarkMode={isDarkMode}
            onSelectArticle={onSelectArticle}
            onMediaArticleClick={onMediaArticleClick}
            onCbsArticleClick={onCbsArticleClick}
            onBulkVerify={onBulkVerify}
            onSelectionChange={(count, handler) => {
              setSelectedCount(count);
              setVerifyHandler(() => handler);
            }}
          />
        ) : (
          <>
            {/* Filters */}
            <div className={`px-4 py-3 border-b ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <label className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>Sorteren:</label>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                    className={`px-2 py-1 rounded border text-sm ${isDarkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-300'}`}
                  >
                    <option value="mediaDate">Media datum</option>
                    <option value="cbsDate">CBS datum</option>
                    <option value="confidence">Betrouwbaarheid</option>
                    <option value="status">Status</option>
                  </select>
                  <button
                    onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
                    className={`p-1 rounded transition-colors ${isDarkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-700'}`}
                    title={sortOrder === "asc" ? "Oplopend" : "Aflopend"}
                  >
                    {sortOrder === "asc" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <label className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>Status:</label>
                  <select
                    value={selectedStatus}
                    onChange={(e) => setSelectedStatus(e.target.value as "all" | "verified" | "unverified")}
                    className={`px-2 py-1 rounded border text-sm ${isDarkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-300'}`}
                  >
                    <option value="all">Alle statussen</option>
                    <option value="verified">Gematcht</option>
                    <option value="unverified">Niet gematcht</option>
                  </select>
                </div>
                <div className="flex items-center gap-2 flex-1">
                  <label className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>Zoeken:</label>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className={`flex-1 px-2 py-1 rounded border text-sm ${isDarkMode ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400' : 'border-gray-300'}`}
                    placeholder="Titel zoeken..."
                  />
                </div>
              </div>
            </div>

            {/* Table */}
            <div className="flex-1 overflow-auto">
              <table className="w-full">
                <thead className={`sticky top-0 z-10 ${isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  <tr>
                    <th className={`px-3 py-2 text-left text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                      Artikel Titel
                    </th>
                    <th className={`px-3 py-2 text-left text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                      Gekoppeld CBS Artikel
                    </th>
                    <th className={`px-3 py-2 text-left text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                      Betrouwbaarheid
                    </th>
                    <th className={`px-3 py-2 text-center text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                      Status
                    </th>
                    <th className={`px-3 py-2 text-left text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                      CBS Datum
                    </th>
                    <th className={`px-3 py-2 text-left text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                      Media Datum
                    </th>
                    <th className={`px-3 py-2 text-center text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                      Acties
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAndSortedArticles.length === 0 ? (
                    <tr>
                      <td colSpan={7} className={`px-4 py-8 text-center text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                        Geen artikelen gevonden
                      </td>
                    </tr>
                  ) : (
                    filteredAndSortedArticles.map((article) => (
                      <tr
                        key={article.id}
                        className={`border-t transition-colors ${
                          isDarkMode 
                            ? 'border-gray-700 hover:bg-gray-700/50' 
                            : 'border-gray-200 hover:bg-gray-50'
                        }`}
                      >
                        <td className={`px-3 py-2 text-xs ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (onMediaArticleClick && article.matchedCbsArticle) {
                                onMediaArticleClick({
                                  id: article.id,
                                  title: article.title,
                                  source: article.source,
                                  sourceType: article.sourceType,
                                  date: new Date(article.date).toLocaleDateString('nl-NL'),
                                  cbsArticle: article.matchedCbsArticle,
                                  snippet: article.snippet,
                                  content: article.content,
                                  link: article.link,
                                  page: article.page,
                                  edition: article.edition
                                });
                              }
                            }}
                            className="text-left hover:underline text-blue-500 hover:text-blue-600"
                          >
                            {article.title}
                          </button>
                        </td>
                        <td className={`px-3 py-2 text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {article.matchedCbsArticle ? (
                            <div className="flex flex-col gap-1">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  e.preventDefault();
                                  onCbsArticleClick?.(article.matchedCbsArticle);
                                }}
                                className="text-blue-500 hover:text-blue-600 hover:underline text-left"
                                title={`Bekijk CBS artikel: ${article.matchedCbsArticle}`}
                              >
                                {article.matchedCbsArticle}
                              </button>
                              {article.cbsCategory && (
                                <Badge className={`${getCategoryColor(article.cbsCategory)} text-xs px-2 py-0 w-fit`}>
                                  {article.cbsCategory}
                                </Badge>
                              )}
                            </div>
                          ) : (
                            <span className="text-gray-400 italic">Geen match</span>
                          )}
                        </td>
                        <td className={`px-3 py-2 text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {article.confidenceScore > 0 ? (
                            <div className="flex items-center gap-2">
                              <div className="flex-1 bg-gray-200 rounded-full h-1.5 max-w-[60px]">
                                <div 
                                  className={`h-1.5 rounded-full ${
                                    article.confidenceScore >= 85 
                                      ? 'bg-green-500' 
                                      : article.confidenceScore >= 50
                                      ? 'bg-yellow-500'
                                      : 'bg-red-500'
                                  }`}
                                  style={{ width: `${article.confidenceScore}%` }}
                                />
                              </div>
                              <span className="font-medium min-w-[2rem] text-right">{article.confidenceScore}%</span>
                            </div>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </td>
                        <td className={`px-3 py-2 text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          <div className="flex justify-center">
                            {article.verificationStatus === "verified" ? (
                              <CheckCircle className="w-4 h-4 text-green-500" />
                            ) : article.verificationStatus === "deferred" ? (
                              <Clock className="w-4 h-4 text-blue-500" />
                            ) : article.verificationStatus === "closed" ? (
                              <XCircle className="w-4 h-4 text-gray-500" />
                            ) : (
                              <AlertCircle className="w-4 h-4 text-orange-500" />
                            )}
                          </div>
                        </td>
                        <td className={`px-3 py-2 text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {article.cbsArticleDate ? new Date(article.cbsArticleDate).toLocaleDateString('nl-NL') : '-'}
                        </td>
                        <td className={`px-3 py-2 text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {new Date(article.date).toLocaleDateString('nl-NL')}
                        </td>
                        <td className="px-3 py-2 text-xs text-center">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectArticle(article);
                            }}
                            className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium text-white transition-all"
                            style={{ backgroundColor: 'var(--cbs-aqua)' }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.backgroundColor = '#005470';
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.backgroundColor = 'var(--cbs-aqua)';
                            }}
                          >
                            <CheckSquare className="w-3 h-3" />
                            Verifiëren
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </>
        )}
      </Card>
    );
  }

  // Full-screen version
  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
      {/* Top Bar */}
      <div className={`border-b sticky top-0 z-50 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white'}`}>
        <div className="max-w-[1880px] mx-auto px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={onBack}
                className={`p-2 rounded transition-all ${isDarkMode ? 'hover:bg-gray-700 text-white' : 'hover:bg-gray-100'}`}
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <Breadcrumb 
                items={[
                  { label: "Dashboard", onClick: onBack },
                  { label: pageTitle || getFilterLabel() || "Matching Platform" }
                ]}
                isDarkMode={isDarkMode}
              />
            </div>
            
            <button
              onClick={onToggleDarkMode}
              className="h-9 w-9 rounded text-white inline-flex items-center justify-center transition-all"
              style={{ backgroundColor: 'var(--cbs-aqua)' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#005470';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--cbs-aqua)';
              }}
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-[1880px] mx-auto px-8 py-8">
        {/* Header with Stats */}
        <div className="flex items-start justify-between mb-6">
          <div>
            <h2 className={`mb-2 ${isDarkMode ? 'text-white' : ''}`}>{pageTitle || getFilterLabel() || "Matching Platform"}</h2>
            <p className={`${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Bekijk en verifieer ML-geclassificeerde media artikelen
            </p>
          </div>

          {/* Stats Cards */}
          <div className="flex gap-3">
            <div className={`p-3 rounded border w-40 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
              <p className={`text-xs text-center mb-2 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Gematcht</p>
              <div className="flex items-center gap-2 justify-center">
                <div className="p-1.5 rounded bg-green-500">
                  <CheckCircle className="w-4 h-4 text-white" />
                </div>
                <p className={`text-xl font-semibold ${isDarkMode ? 'text-white' : ''}`}>{verifiedCount}</p>
              </div>
            </div>
            <div className={`p-3 rounded border w-40 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
              <p className={`text-xs text-center mb-2 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Niet gematcht</p>
              <div className="flex items-center gap-2 justify-center">
                <div className="p-1.5 rounded bg-orange-500">
                  <AlertCircle className="w-4 h-4 text-white" />
                </div>
                <p className={`text-xl font-semibold ${isDarkMode ? 'text-white' : ''}`}>{unverifiedCount}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className={`p-4 rounded border mb-6 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <label className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>Sorteren:</label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                className={`px-3 py-2 rounded border ${isDarkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-300'}`}
              >
                <option value="mediaDate">Media datum</option>
                <option value="cbsDate">CBS datum</option>
                <option value="confidence">Betrouwbaarheid</option>
                <option value="status">Status</option>
              </select>
              <button
                onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
                className={`p-2 rounded transition-colors ${isDarkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-700'}`}
                title={sortOrder === "asc" ? "Oplopend" : "Aflopend"}
              >
                {sortOrder === "asc" ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
              </button>
            </div>
            <div className="flex items-center gap-2">
              <label className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>Status:</label>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value as "all" | "verified" | "unverified")}
                className={`px-3 py-2 rounded border ${isDarkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-300'}`}
              >
                <option value="all">Alle statussen</option>
                <option value="verified">Gematcht</option>
                <option value="unverified">Niet gematcht</option>
              </select>
            </div>
            <div className="flex items-center gap-2 flex-1">
              <label className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>Zoeken:</label>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`flex-1 px-3 py-1.5 rounded border text-sm ${isDarkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-300'}`}
                placeholder="Titel zoeken..."
              />
            </div>
          </div>
        </div>

        {/* Table */}
        <div className={`rounded border overflow-hidden ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
          <table className="w-full">
            <thead className={isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}>
              <tr>
                <th className={`px-4 py-3 text-left text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                  Artikel Titel
                </th>
                <th className={`px-4 py-3 text-left text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                  Gekoppeld CBS Artikel
                </th>
                <th className={`px-4 py-3 text-left text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                  Betrouwbaarheid
                </th>
                <th className={`px-4 py-3 text-center text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                  Status
                </th>
                <th className={`px-4 py-3 text-left text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                  CBS Datum
                </th>
                <th className={`px-4 py-3 text-left text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                  Media Datum
                </th>
                <th className={`px-4 py-3 text-center text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
                  Acties
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredAndSortedArticles.map((article) => (
                <tr
                  key={article.id}
                  className={`border-t transition-colors ${
                    isDarkMode 
                      ? 'border-gray-700 hover:bg-gray-700' 
                      : 'border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  <td className={`px-4 py-3 text-sm ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (onMediaArticleClick) {
                          onMediaArticleClick({
                            id: article.id,
                            title: article.title,
                            source: article.source,
                            sourceType: article.sourceType,
                            date: new Date(article.date).toLocaleDateString('nl-NL'),
                            cbsArticle: article.matchedCbsArticle,
                            snippet: article.snippet,
                            content: article.content,
                            link: article.link,
                            page: article.page,
                            edition: article.edition
                          });
                        }
                      }}
                      className="text-left hover:underline text-blue-500 hover:text-blue-600"
                    >
                      {article.title}
                    </button>
                  </td>
                  <td className={`px-4 py-3 text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    {article.matchedCbsArticle ? (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          e.preventDefault();
                          onCbsArticleClick?.(article.matchedCbsArticle);
                        }}
                        className="text-blue-500 hover:text-blue-600 hover:underline text-left"
                        title={`Bekijk CBS artikel: ${article.matchedCbsArticle}`}
                      >
                        {article.matchedCbsArticle}
                      </button>
                    ) : (
                      <span className="text-gray-400 italic">Geen match</span>
                    )}
                  </td>
                  <td className={`px-4 py-3 text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    {article.confidenceScore > 0 ? (
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 rounded-full h-2 max-w-[100px]">
                          <div 
                            className={`h-2 rounded-full ${
                              article.confidenceScore >= 85 
                                ? 'bg-green-500' 
                                : article.confidenceScore >= 50
                                ? 'bg-yellow-500'
                                : 'bg-red-500'
                            }`}
                            style={{ width: `${article.confidenceScore}%` }}
                          />
                        </div>
                        <span className="font-medium min-w-[3rem] text-right">{article.confidenceScore}%</span>
                      </div>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </td>
                  <td className={`px-4 py-3 text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    <div className="flex justify-center">
                      {article.verificationStatus === "verified" ? (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      ) : article.verificationStatus === "deferred" ? (
                        <Clock className="w-5 h-5 text-blue-500" />
                      ) : article.verificationStatus === "closed" ? (
                        <XCircle className="w-5 h-5 text-gray-500" />
                      ) : (
                        <AlertCircle className="w-5 h-5 text-orange-500" />
                      )}
                    </div>
                  </td>
                  <td className={`px-4 py-3 text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    {article.cbsArticleDate ? new Date(article.cbsArticleDate).toLocaleDateString('nl-NL') : '-'}
                  </td>
                  <td className={`px-4 py-3 text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    {new Date(article.date).toLocaleDateString('nl-NL')}
                  </td>
                  <td className="px-4 py-3 text-sm text-center">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectArticle(article);
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium text-white transition-all"
                      style={{ backgroundColor: 'var(--cbs-aqua)' }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = '#005470';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = 'var(--cbs-aqua)';
                      }}
                    >
                      <CheckSquare className="w-3.5 h-3.5" />
                      Verifiëren
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export type { MediaArticleMatch };