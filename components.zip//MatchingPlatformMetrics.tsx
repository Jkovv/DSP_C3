import { Card } from "./ui/card";
import { CheckCircle, AlertCircle, Zap, Hand, User, Baby } from "lucide-react";

interface MatchingPlatformMetricsProps {
  isDarkMode?: boolean;
  onViewPlatform?: () => void;
  hideViewButton?: boolean;
  metrics?: {
    totalMatches: number;
    verified: number;
    pending: number;
    automatic: number;
    manual: number;
    totalChildren: number;
    totalParents: number;
    inAfwachting: number;
  };
}

export function MatchingPlatformMetrics({ isDarkMode = false, onViewPlatform, hideViewButton = false, metrics: metricsProps }: MatchingPlatformMetricsProps) {
  // Use provided metrics or fallback to mock data
  const metrics = metricsProps || {
    totalMatches: 15,
    verified: 7,
    pending: 8,
    automatic: 12,
    manual: 3,
    totalChildren: 23,
    totalParents: 5,
    inAfwachting: 16
  };

  return (
    <Card className={`border-2 w-full flex flex-col overflow-hidden rounded ${isDarkMode ? 'bg-gray-800 border-gray-700' : ''}`}>
      <div className="flex items-center justify-between px-5 h-10 rounded-t" style={{ backgroundColor: '#0580a1' }}>
        <h3 className="text-white mb-0 text-base">Matching Platform Metrics</h3>
        {onViewPlatform && !hideViewButton && (
          <button
            onClick={onViewPlatform}
            className="h-6 px-2 text-xs whitespace-nowrap rounded transition-all border"
            style={{ backgroundColor: '#ffffff', color: '#005470', borderColor: '#005470' }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = '#005470';
              e.currentTarget.style.color = '#ffffff';
              e.currentTarget.style.borderColor = '#005470';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = '#ffffff';
              e.currentTarget.style.color = '#005470';
              e.currentTarget.style.borderColor = '#005470';
            }}
          >
            Open Platform
          </button>
        )}
      </div>

      <div className="px-4 pt-3 pb-4 grid grid-cols-2 gap-3 -mt-2">
        {/* Total Children */}
        <div className={`p-3 rounded border ${isDarkMode ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-200'}`}>
          <div className="flex items-center gap-2 mb-2">
            <div className="p-1.5 rounded" style={{ backgroundColor: '#a855f720' }}>
              <Baby className="w-4 h-4 text-purple-600" />
            </div>
            <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Aantal children</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className={`text-2xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {metrics.totalChildren}
            </span>
          </div>
        </div>

        {/* Total Parents */}
        <div className={`p-3 rounded border ${isDarkMode ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-200'}`}>
          <div className="flex items-center gap-2 mb-2">
            <div className="p-1.5 rounded" style={{ backgroundColor: '#3b82f620' }}>
              <User className="w-4 h-4 text-blue-600" />
            </div>
            <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Aantal parents</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className={`text-2xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {metrics.totalParents}
            </span>
          </div>
        </div>

        {/* In afwachting */}
        <div className={`p-3 rounded border ${isDarkMode ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-200'}`}>
          <div className="flex items-center gap-2 mb-2">
            <div className="p-1.5 rounded" style={{ backgroundColor: '#f9731620' }}>
              <AlertCircle className="w-4 h-4 text-orange-500" />
            </div>
            <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>In afwachting</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className={`text-2xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {metrics.inAfwachting}
            </span>
          </div>
        </div>

        {/* Verified */}
        <div className={`p-3 rounded border ${isDarkMode ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-200'}`}>
          <div className="flex items-center gap-2 mb-2">
            <div className="p-1.5 rounded" style={{ backgroundColor: '#22c55e20' }}>
              <CheckCircle className="w-4 h-4 text-green-500" />
            </div>
            <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Gematcht</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className={`text-2xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {metrics.verified}
            </span>
            <span className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>
              van {metrics.totalChildren}
            </span>
          </div>
        </div>

        {/* Average Confidence */}
        <div className={`p-3 rounded border ${isDarkMode ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-200'}`}>
          <div className="flex items-center gap-2 mb-2">
            <div className="p-1.5 rounded" style={{ backgroundColor: '#0580a120' }}>
              <Zap className="w-4 h-4" style={{ color: 'var(--cbs-aqua)' }} />
            </div>
            <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Auto matches</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className={`text-2xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {metrics.automatic}
            </span>
          </div>
        </div>

        {/* Low Confidence */}
        <div className={`p-3 rounded border ${isDarkMode ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-200'}`}>
          <div className="flex items-center gap-2 mb-2">
            <div className="p-1.5 rounded" style={{ backgroundColor: '#ef444420' }}>
              <Hand className="w-4 h-4 text-red-500" />
            </div>
            <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Handmatige matches</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className={`text-2xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              {metrics.manual}
            </span>
          </div>
        </div>
      </div>
    </Card>
  );
}