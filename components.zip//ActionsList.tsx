import { AlertCircle, Clock, FileQuestion, XCircle } from "lucide-react";
import { Card } from "./ui/card";

interface ActionsListProps {
  isDarkMode: boolean;
  onActionClick: (action: "orphans" | "deferred" | "errors" | "closed") => void;
  counts: {
    orphans: number;
    deferred: number;
    errors: number;
    closed: number;
  };
}

export function ActionsList({ isDarkMode, onActionClick, counts }: ActionsListProps) {
  const actions = [
    {
      id: "orphans" as const,
      label: "Weeskinderen",
      icon: FileQuestion,
      count: counts.orphans,
      description: "Media-artikelen zonder match",
      color: "text-orange-600 dark:text-orange-400"
    },
    {
      id: "deferred" as const,
      label: "Uitgestelde kinderen",
      icon: Clock,
      count: counts.deferred,
      description: "Artikelen uitgesteld voor later",
      color: "text-blue-600 dark:text-blue-400"
    },
    {
      id: "errors" as const,
      label: "Error matches",
      icon: AlertCircle,
      count: counts.errors,
      description: "Foutieve matches",
      color: "text-red-600 dark:text-red-400"
    },
    {
      id: "closed" as const,
      label: "Gesloten kinderen",
      icon: XCircle,
      count: counts.closed,
      description: "Niet-relevante artikelen",
      color: "text-gray-600 dark:text-gray-400"
    }
  ];

  return (
    <Card className={`border-2 w-full h-full flex flex-col overflow-hidden rounded ${isDarkMode ? 'bg-gray-800 border-gray-700' : ''}`}>
      <div className="flex items-center justify-between px-5 h-10 rounded-t" style={{ backgroundColor: '#0580a1' }}>
        <h3 className="text-white mb-0 text-base">Acties</h3>
      </div>
      
      <style>{`
        .actions-list-scroll {
          overflow-y: scroll !important;
        }
        .actions-list-scroll::-webkit-scrollbar {
          width: 8px;
          display: block !important;
        }
        .actions-list-scroll::-webkit-scrollbar-track {
          background: ${isDarkMode ? '#1f2937' : '#f1f5f9'};
          border-radius: 4px;
        }
        .actions-list-scroll::-webkit-scrollbar-thumb {
          background: ${isDarkMode ? '#4b5563' : '#cbd5e1'};
          border-radius: 4px;
          min-height: 40px;
        }
        .actions-list-scroll::-webkit-scrollbar-thumb:hover {
          background: ${isDarkMode ? '#6b7280' : '#94a3b8'};
        }
      `}</style>
      
      <div 
        className="flex-1 px-4 pb-4 actions-list-scroll -mt-2"
        style={{
          overflowY: 'scroll',
          scrollbarWidth: 'thin',
          scrollbarColor: isDarkMode ? '#4b5563 #1f2937' : '#cbd5e1 #f1f5f9'
        }}
      >
        <div className="space-y-2">
          {actions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.id}
                onClick={() => onActionClick(action.id)}
                className={`w-full text-left pb-2 border-b last:border-b-0 cursor-pointer transition-colors ${
                  isDarkMode 
                    ? 'border-gray-700 hover:bg-gray-700/50' 
                    : 'border-gray-200 hover:bg-gray-50'
                } -mx-2 px-2 rounded`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    <div className={`${action.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <div className={`text-sm ${isDarkMode ? 'text-gray-100' : 'text-gray-900'}`}>
                        {action.label}
                      </div>
                      <div className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                        {action.description}
                      </div>
                    </div>
                  </div>
                  <div className={`ml-4 px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    isDarkMode ? 'bg-gray-700 text-white' : 'bg-gray-100 text-gray-900'
                  }`}>
                    {action.count}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </Card>
  );
}