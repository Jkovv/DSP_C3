import { X, Calendar, Hash, Tag, FileText, Newspaper, ChevronDown, ChevronUp, ArrowLeft } from "lucide-react";
import { useState } from "react";

interface MediaArticle {
  id: string;
  title: string;
  source: string;
  sourceType: string;
  date: string;
  cbsArticle: string;
  snippet: string;
  content: string;
  link: string;
  page?: string;
  edition?: string;
}

interface Article {
  id: string;
  title: string;
  date: string;
  category: string;
  summary?: string;
}

interface CBSArticleDetailModalProps {
  article: Article | null;
  onClose: () => void;
  isDarkMode: boolean;
  onMediaArticleClick?: (article: MediaArticle) => void;
  onBack?: () => void;
}

export function CBSArticleDetailModal({ article, onClose, isDarkMode, onMediaArticleClick, onBack }: CBSArticleDetailModalProps) {
  const [citationsExpanded, setCitationsExpanded] = useState(false);
  
  if (!article) return null;

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Arbeid en inkomen":
        return "#0580a1";
      case "Economie":
        return "#271D6C";
      case "Maatschappij":
        return "#af0e80";
      default:
        return "#6b7280";
    }
  };

  // Generate mock full content for demonstration
  const fullContent = `${article.summary || 'Dit CBS artikel bevat statistische gegevens en analyse over ' + article.category.toLowerCase() + '.'}\n\nDit artikel is gepubliceerd door het Centraal Bureau voor de Statistiek en bevat officiële statistieken en data-analyse. Voor meer gedetailleerde informatie en de volledige dataset, kunt u de originele publicatie raadplegen op de CBS website.\n\nDe gegevens in dit artikel zijn verzameld volgens de officiële CBS methodologie en voldoen aan de hoogste statistische standaarden.`;

  // Mock citations data
  const citations: MediaArticle[] = [
    {
      id: "MA001",
      title: "Economische groei zet door in derde kwartaal",
      source: "NRC Handelsblad",
      sourceType: "Print",
      date: "2024-01-15",
      cbsArticle: article.id,
      snippet: "Volgens recent gepubliceerde cijfers van het CBS groeide de Nederlandse economie met 0.5% in het derde kwartaal...",
      content: "De Nederlandse economie blijft groeien. Volgens recent gepubliceerde cijfers van het CBS groeide de Nederlandse economie met 0.5% in het derde kwartaal van 2024. Deze groei is vooral te danken aan de sterke export en consumentenbestedingen.",
      link: "https://example.com/article1",
      page: "3",
      edition: "Ochtend"
    },
    {
      id: "MA002",
      title: "Werkloosheid daalt naar laagste niveau in jaren",
      source: "De Telegraaf",
      sourceType: "Online",
      date: "2024-01-14",
      cbsArticle: article.id,
      snippet: "Het CBS rapporteerde vandaag dat de werkloosheid is gedaald naar 3.2%, het laagste niveau sinds 2019...",
      content: "Goed nieuws voor de arbeidsmarkt. Het CBS rapporteerde vandaag dat de werkloosheid is gedaald naar 3.2%, het laagste niveau sinds 2019. Vooral in de technische sectoren en de zorg is er een groeiende vraag naar personeel.",
      link: "https://example.com/article2"
    },
    {
      id: "MA003",
      title: "Inflatie stabiliseert volgens nieuwe CBS cijfers",
      source: "Het Financieele Dagblad",
      sourceType: "Print",
      date: "2024-01-13",
      cbsArticle: article.id,
      snippet: "De inflatie in Nederland lijkt te stabiliseren op 2.8%, blijkt uit nieuwe cijfers van het CBS...",
      content: "De inflatie in Nederland lijkt te stabiliseren op 2.8%, blijkt uit nieuwe cijfers van het CBS. Dit is een positief signaal na maanden van stijgende prijzen. Economen zijn voorzichtig optimistisch over deze trend.",
      link: "https://example.com/article3",
      page: "1",
      edition: "Eerste editie"
    }
  ];

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-8"
        onClick={onClose}
      >
        {/* Modal */}
        <div
          className={`w-full max-w-4xl max-h-[90vh] overflow-hidden rounded shadow-xl ${
            isDarkMode ? 'bg-gray-800' : 'bg-white'
          }`}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className={`p-6 border-b ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-3 flex-1">
                {onBack && (
                  <button
                    onClick={onBack}
                    className={`p-2 rounded transition-colors mt-0.5 ${
                      isDarkMode ? 'hover:bg-gray-700 text-white' : 'hover:bg-gray-100'
                    }`}
                    title="Terug naar media artikel"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </button>
                )}
                <div className="flex-1">
                  <h2 className={`text-xl font-medium mb-3 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    {article.title}
                  </h2>
                  <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar className={`w-4 h-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                      <span className={isDarkMode ? 'text-gray-300' : 'text-gray-700'}>
                        {article.date}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Tag className={`w-4 h-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                      <span 
                        className="px-2 py-0.5 rounded text-white text-xs font-medium"
                        style={{ backgroundColor: getCategoryColor(article.category) }}
                      >
                        {article.category}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <button
                onClick={onClose}
                className={`p-2 rounded transition-colors ${
                  isDarkMode ? 'hover:bg-gray-700 text-white' : 'hover:bg-gray-100'
                }`}
                style={{ visibility: onBack ? 'hidden' : 'visible' }}
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="p-6 overflow-y-auto max-h-[calc(90vh-180px)]">
            {/* Metadata Grid */}
            <div className={`grid grid-cols-2 gap-4 mb-6 p-4 rounded ${
              isDarkMode ? 'bg-gray-700' : 'bg-gray-50'
            }`}>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Hash className={`w-4 h-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                  <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    Artikel ID
                  </span>
                </div>
                <div className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {article.id}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Tag className={`w-4 h-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                  <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    Categorie
                  </span>
                </div>
                <div className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {article.category}
                </div>
              </div>
            </div>

            {/* Summary */}
            {article.summary && (
              <div className="mb-6">
                <h3 className={`text-sm font-medium mb-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  Samenvatting
                </h3>
                <p className={`text-sm leading-relaxed ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  {article.summary}
                </p>
              </div>
            )}

            {/* Full Content */}
            <div className="mb-6">
              <h3 className={`text-sm font-medium mb-2 flex items-center gap-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                <FileText className="w-4 h-4" />
                Volledige inhoud
              </h3>
              <div className={`text-sm leading-relaxed whitespace-pre-wrap ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {fullContent}
              </div>
            </div>

            {/* Citations Section */}
            <div>
              <button
                onClick={() => setCitationsExpanded(!citationsExpanded)}
                className={`w-full p-4 rounded border flex items-center justify-between transition-colors ${
                  isDarkMode 
                    ? 'bg-gray-700 border-gray-600 hover:bg-gray-600' 
                    : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Newspaper className={`w-5 h-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
                  <span className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    Aantal citaties
                  </span>
                  <span className={`ml-2 px-2 py-0.5 rounded text-xs font-medium ${
                    isDarkMode ? 'bg-gray-600 text-white' : 'bg-gray-200 text-gray-700'
                  }`}>
                    {citations.length}
                  </span>
                </div>
                {citationsExpanded ? (
                  <ChevronUp className={`w-5 h-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
                ) : (
                  <ChevronDown className={`w-5 h-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
                )}
              </button>

              {citationsExpanded && (
                <div className={`mt-3 p-4 rounded border ${
                  isDarkMode ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-200'
                }`}>
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {citations.map((citation) => (
                      <div
                        key={citation.id}
                        onClick={() => {
                          onClose();
                          onMediaArticleClick?.(citation);
                        }}
                        className={`p-3 rounded border cursor-pointer transition-colors ${
                          isDarkMode 
                            ? 'bg-gray-800 border-gray-600 hover:bg-gray-750 hover:border-gray-500' 
                            : 'bg-gray-50 border-gray-200 hover:bg-gray-100 hover:border-gray-300'
                        }`}
                      >
                        <div className={`text-sm font-medium mb-2 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                          {citation.title}
                        </div>
                        <div className="flex items-center gap-4 text-xs mb-2">
                          <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                            {citation.source}
                          </span>
                          <span className={isDarkMode ? 'text-gray-500' : 'text-gray-400'}>•</span>
                          <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                            {new Date(citation.date).toLocaleDateString('nl-NL', { 
                              day: 'numeric', 
                              month: 'short', 
                              year: 'numeric' 
                            })}
                          </span>
                          <span className={isDarkMode ? 'text-gray-500' : 'text-gray-400'}>•</span>
                          <span className={`px-2 py-0.5 rounded ${
                            isDarkMode ? 'bg-gray-600 text-gray-300' : 'bg-gray-200 text-gray-700'
                          }`}>
                            {citation.sourceType}
                          </span>
                        </div>
                        <p className={`text-xs line-clamp-2 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {citation.snippet}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}