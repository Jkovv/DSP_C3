import { Search, SlidersHorizontal, Moon, Sun, Home, GitCompare } from "lucide-react";
import { Button } from "./ui/button";
import cbsLogo from "figma:asset/65598e5836e7d4529c8a697daab783734593739d.png";

interface DashboardHeaderProps {
  onSearchClick: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}
export function DashboardHeader({ onSearchClick, isDarkMode, onToggleDarkMode }: DashboardHeaderProps) {
  return (
    <header className={`border-b sticky top-0 z-50 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white'}`}>
      <div className="max-w-[1880px] mx-auto px-8 py-4 flex items-center justify-between">
        {/* Logo and Title */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <img
              src={cbsLogo}
              alt="CBS Logo"
              className="w-12 h-12 object-contain"
            />
            <div>
              <h1 className={`mb-0 ${isDarkMode ? 'text-white' : ''}`}>Matching Platform</h1>
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>Centraal Bureau voor de Statistiek</p>
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={onSearchClick}
            style={{ backgroundColor: 'var(--cbs-aqua)' }}
            className="h-9 px-6 rounded text-white inline-flex items-center justify-center transition-all text-sm"
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = '#005470';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--cbs-aqua)';
            }}
          >
            <Search className="w-4 h-4 mr-2" />
            Zoeken
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={onToggleDarkMode}
            className="h-9 w-9 rounded text-white inline-flex items-center justify-center transition-all"
            style={{ backgroundColor: 'var(--cbs-aqua)' }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = '#005470';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--cbs-aqua)';
            }}
          >
            {isDarkMode ? (
              <Sun className="w-4 h-4" />
            ) : (
              <Moon className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
}