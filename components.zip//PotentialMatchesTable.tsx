import { useState, useMemo, useEffect, useRef } from "react";
import { ChevronRight, ChevronDown, CheckSquare, CheckCircle, AlertCircle, Square, User, Baby } from "lucide-react";
import { MediaArticleMatch } from "./MatchingPlatform";
import { Badge } from "./ui/badge";

// Mock CBS article summaries (moved outside component to prevent re-renders)
const cbsArticleSummaries: { [key: string]: string } = {
  "Arbeidsmarkt Q4 2025": "Werkloosheid gestegen met 0,3 procentpunt in Q4 2025. Het werkloosheidspercentage kwam uit op 3,9%. Aantal werklozen steeg naar 385.000 personen.",
  "Inflatie januari 2026": "Inflatie daalde naar 3,2% in januari 2026, een daling van 0,3 procentpunt. Prijsstijgingen vooral in voeding en energie.",
  "Werkloosheid november 2025": "Werkloosheid stabiliseert op 3,6% in november. Aantal openstaande vacatures blijft hoog ondanks lichte daling.",
  "Woningmarkt 2025": "Huizenprijzen dalen voor het eerst in drie jaar met gemiddeld 1,8%. Verkooptijd neemt toe naar 52 dagen.",
  "Bedrijvigheid Q1 2026": "Bedrijfsvertrouwen neemt licht af in Q1. Export blijft groeien met 3,2%, binnenlandse bestedingen vlakken af.",
};

interface PotentialMatchesTableProps {
  articles: MediaArticleMatch[];
  isDarkMode: boolean;
  onSelectArticle: (article: MediaArticleMatch) => void;
  onMediaArticleClick?: (article: any) => void;
  onCbsArticleClick?: (cbsArticleTitle: string) => void;
  onBulkVerify?: (cbsArticle: string, articleIds: string[]) => void;
  onSelectionChange?: (selectedCount: number, handleVerify: () => void) => void;
}

interface ParentGroup {
  cbsArticle: string;
  cbsArticleDate: string;
  cbsCategory: string;
  cbsSummary: string;
  children: MediaArticleMatch[];
  allVerified: boolean;
  totalConfidence: number;
}

export function PotentialMatchesTable({
  articles,
  isDarkMode,
  onSelectArticle,
  onMediaArticleClick,
  onCbsArticleClick,
  onBulkVerify,
  onSelectionChange
}: PotentialMatchesTableProps) {
  const [expandedParents, setExpandedParents] = useState<Set<string>>(new Set());
  const [selectedChildren, setSelectedChildren] = useState<Set<string>>(new Set());
  const [hoveredItem, setHoveredItem] = useState<{ type: 'parent' | 'child'; id: string } | null>(null);
  const initializedRef = useRef(false);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Arbeid en inkomen":
        return "bg-[#0580a1] text-white";
      case "Economie":
        return "bg-[#271D6C] text-white";
      case "Maatschappij":
        return "bg-[#af0e80] text-white";
      case "Bouwen en wonen":
        return "bg-[#f39200] text-white";
      default:
        return "bg-gray-200 text-gray-800";
    }
  };

  // Group articles by CBS article (parent)
  const parentGroups = useMemo<ParentGroup[]>(() => {
    const groups = new Map<string, ParentGroup>();

    articles.forEach(article => {
      const cbsArticle = article.matchedCbsArticle;
      if (!cbsArticle) return;

      if (!groups.has(cbsArticle)) {
        groups.set(cbsArticle, {
          cbsArticle,
          cbsArticleDate: article.cbsArticleDate || '',
          cbsCategory: article.cbsCategory || '',
          cbsSummary: cbsArticleSummaries[cbsArticle] || '',
          children: [],
          allVerified: true,
          totalConfidence: 0
        });
      }

      const group = groups.get(cbsArticle)!;
      group.children.push(article);
      
      if (article.verificationStatus !== 'verified') {
        group.allVerified = false;
      }
    });

    // Calculate average confidence for each parent
    groups.forEach(group => {
      const sum = group.children.reduce((acc, child) => acc + child.confidenceScore, 0);
      group.totalConfidence = Math.round(sum / group.children.length);
    });

    // Sort by CBS article name
    return Array.from(groups.values()).sort((a, b) => 
      a.cbsArticle.localeCompare(b.cbsArticle)
    );
  }, [articles]);

  // Select all children by default ONLY on initial load
  useEffect(() => {
    if (!initializedRef.current && parentGroups.length > 0) {
      const allChildIds = parentGroups.flatMap(parent => 
        parent.children.map(c => c.id)
      );
      setSelectedChildren(new Set(allChildIds));
      
      // Expand all parents by default
      const allParentNames = parentGroups.map(p => p.cbsArticle);
      setExpandedParents(new Set(allParentNames));
      
      initializedRef.current = true;
    }
  }, [parentGroups]);

  // Check if all items are selected
  const allChildIds = useMemo(() => {
    return parentGroups.flatMap(parent => 
      parent.children.map(c => c.id)
    );
  }, [parentGroups]);

  const allSelected = allChildIds.length > 0 && allChildIds.every(id => selectedChildren.has(id));
  const someSelected = allChildIds.some(id => selectedChildren.has(id));

  const toggleSelectAll = () => {
    if (allSelected) {
      // Deselect all
      setSelectedChildren(new Set());
    } else {
      // Select all
      setSelectedChildren(new Set(allChildIds));
    }
  };

  const toggleParent = (cbsArticle: string) => {
    setExpandedParents(prev => {
      const next = new Set(prev);
      if (next.has(cbsArticle)) {
        next.delete(cbsArticle);
      } else {
        next.add(cbsArticle);
      }
      return next;
    });
  };

  const toggleChildSelection = (childId: string) => {
    setSelectedChildren(prev => {
      const next = new Set(prev);
      if (next.has(childId)) {
        next.delete(childId);
      } else {
        next.add(childId);
      }
      return next;
    });
  };

  const toggleAllChildren = (parent: ParentGroup) => {
    const childIds = parent.children.map(c => c.id);
    
    const allSelected = childIds.every(id => selectedChildren.has(id));
    
    setSelectedChildren(prev => {
      const next = new Set(prev);
      if (allSelected) {
        // Deselect all
        childIds.forEach(id => next.delete(id));
      } else {
        // Select all
        childIds.forEach(id => next.add(id));
      }
      return next;
    });
  };

  const handleBulkVerify = (parent: ParentGroup) => {
    const selectedIds = parent.children
      .filter(c => selectedChildren.has(c.id))
      .map(c => c.id);
    
    if (selectedIds.length > 0 && onBulkVerify) {
      onBulkVerify(parent.cbsArticle, selectedIds);
      // Clear selections after verification
      setSelectedChildren(prev => {
        const next = new Set(prev);
        selectedIds.forEach(id => next.delete(id));
        return next;
      });
    }
  };

  const handleVerifyAllSelected = () => {
    // Group selected articles by parent
    const parentMap = new Map<string, string[]>();
    
    parentGroups.forEach(parent => {
      const selectedIds = parent.children
        .filter(c => selectedChildren.has(c.id))
        .map(c => c.id);
      
      if (selectedIds.length > 0) {
        parentMap.set(parent.cbsArticle, selectedIds);
      }
    });

    // Verify each parent's selected children
    parentMap.forEach((articleIds, cbsArticle) => {
      if (onBulkVerify) {
        onBulkVerify(cbsArticle, articleIds);
      }
    });

    // Clear all selections
    setSelectedChildren(new Set());
  };

  const totalSelectedCount = selectedChildren.size;

  // Notify parent about selection changes
  useEffect(() => {
    if (onSelectionChange) {
      onSelectionChange(totalSelectedCount, handleVerifyAllSelected);
    }
  }, [totalSelectedCount]);

  return (
    <div className="flex-1 flex flex-col overflow-hidden -mt-2">
      <div className="flex-1 overflow-auto">
        <table className="w-full">
        <thead className={`sticky top-0 z-10 ${isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
          <tr>
            <th className={`px-3 py-2 text-left text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
              CBS Artikel (Parent)
            </th>
            <th className={`px-3 py-2 text-center text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
              Matches
            </th>
            <th className={`px-3 py-2 text-left text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
              Gem. Betrouwbaarheid
            </th>
            <th className={`px-3 py-2 text-left text-xs font-medium uppercase tracking-wider ${isDarkMode ? 'text-gray-300' : 'text-gray-500'}`}>
              CBS Datum
            </th>
          </tr>
        </thead>
        <tbody>
          {parentGroups.length === 0 ? (
            <tr>
              <td colSpan={4} className={`px-4 py-8 text-center text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                Geen potentiele matches gevonden
              </td>
            </tr>
          ) : (
            parentGroups.flatMap((parent) => {
              const isExpanded = expandedParents.has(parent.cbsArticle);
              const childIds = parent.children.map(c => c.id);
              const hasChildren = childIds.length > 0;
              const allChildrenSelected = hasChildren && childIds.every(id => selectedChildren.has(id));
              const someChildrenSelected = hasChildren && childIds.some(id => selectedChildren.has(id));
              const selectedCount = childIds.filter(id => selectedChildren.has(id)).length;
              
              const rows = [
                // Parent Row
                <tr
                  key={`parent-${parent.cbsArticle}`}
                  className={`border-t transition-colors cursor-pointer ${
                    isDarkMode 
                      ? 'border-gray-700 hover:bg-blue-900/30 bg-blue-900/20' 
                      : 'border-gray-200 hover:bg-blue-100 bg-blue-50'
                  }`}
                >
                  <td className={`px-3 py-2.5 text-xs font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    <div className="flex items-center gap-2">
                      {/* Select All Checkbox */}
                      <input
                        type="checkbox"
                        checked={allChildrenSelected}
                        ref={(el) => {
                          if (el) {
                            el.indeterminate = someChildrenSelected && !allChildrenSelected;
                          }
                        }}
                        onChange={(e) => {
                          e.stopPropagation();
                          toggleAllChildren(parent);
                        }}
                        className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                        title={allChildrenSelected ? "Deselecteer alles" : "Selecteer alles"}
                      />
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleParent(parent.cbsArticle);
                        }}
                        className="p-0.5 hover:bg-gray-200 dark:hover:bg-gray-600 rounded transition-colors"
                      >
                        {isExpanded ? (
                          <ChevronDown className="w-4 h-4" />
                        ) : (
                          <ChevronRight className="w-4 h-4" />
                        )}
                      </button>
                      <User className="w-4 h-4 text-blue-600" />
                      <div className="relative">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onCbsArticleClick?.(parent.cbsArticle);
                          }}
                          onMouseEnter={() => setHoveredItem({ type: 'parent', id: parent.cbsArticle })}
                          onMouseLeave={() => setHoveredItem(null)}
                          className="text-left hover:underline text-blue-600 dark:text-blue-400 font-semibold"
                        >
                          {parent.cbsArticle}
                        </button>
                        {hoveredItem?.type === 'parent' && hoveredItem.id === parent.cbsArticle && parent.cbsSummary && (
                          <div className={`absolute left-0 top-full mt-2 p-3 rounded-lg shadow-xl border z-50 w-96 ${
                            isDarkMode 
                              ? 'bg-gray-900 border-gray-700 text-gray-200' 
                              : 'bg-white border-gray-200 text-gray-800'
                          }`}>
                            <p className="text-sm leading-relaxed">{parent.cbsSummary}</p>
                          </div>
                        )}
                      </div>
                      {parent.cbsCategory && (
                        <Badge className={`${getCategoryColor(parent.cbsCategory)} text-xs px-2 py-0 w-fit`}>
                          {parent.cbsCategory}
                        </Badge>
                      )}
                    </div>
                  </td>
                  <td className={`px-3 py-2.5 text-xs text-center ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    <span className={`inline-flex items-center justify-center px-2 py-0.5 rounded-full text-xs font-medium ${
                      isDarkMode ? 'bg-gray-700 text-white' : 'bg-blue-100 text-blue-800'
                    }`}>
                      {parent.children.length}
                    </span>
                  </td>
                  <td className={`px-3 py-2.5 text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-1.5 max-w-[60px]">
                        <div 
                          className="h-1.5 rounded-full bg-green-500"
                          style={{ width: `${parent.totalConfidence}%` }}
                        />
                      </div>
                      <span className="font-medium min-w-[2rem] text-right">{parent.totalConfidence}%</span>
                    </div>
                  </td>
                  <td className={`px-3 py-2.5 text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    {parent.cbsArticleDate ? new Date(parent.cbsArticleDate).toLocaleDateString('nl-NL') : '-'}
                  </td>
                </tr>
              ];

              // Add children rows if expanded
              if (isExpanded) {
                parent.children.forEach((child) => {
                  const isSelected = selectedChildren.has(child.id);
                  const isVerified = child.verificationStatus === 'verified';
                  
                  rows.push(
                    <tr
                      key={`child-${child.id}`}
                      className={`border-t transition-colors ${
                        isDarkMode 
                          ? 'border-gray-700 hover:bg-purple-900/20 bg-gray-800' 
                          : 'border-gray-200 hover:bg-purple-50 bg-white'
                      }`}
                    >
                      <td className={`px-3 py-2 text-xs ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                        <div className="flex items-center gap-2 pl-7">
                          {/* Child Checkbox */}
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={(e) => {
                              e.stopPropagation();
                              toggleChildSelection(child.id);
                            }}
                            className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                          />
                          <Baby className="w-4 h-4 text-purple-600" />
                          <div className="relative flex-1">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                if (onMediaArticleClick) {
                                  onMediaArticleClick({
                                    id: child.id,
                                    title: child.title,
                                    source: child.source,
                                    sourceType: child.sourceType,
                                    date: new Date(child.date).toLocaleDateString('nl-NL'),
                                    cbsArticle: child.matchedCbsArticle,
                                    snippet: child.snippet,
                                    content: child.content,
                                    link: child.link,
                                    page: child.page,
                                    edition: child.edition
                                  });
                                }
                              }}
                              onMouseEnter={() => setHoveredItem({ type: 'child', id: child.id })}
                              onMouseLeave={() => setHoveredItem(null)}
                              className="text-left hover:underline text-blue-500 hover:text-blue-600"
                            >
                              {child.title}
                            </button>
                            {hoveredItem?.type === 'child' && hoveredItem.id === child.id && child.snippet && (
                              <div className={`absolute left-0 top-full mt-2 p-3 rounded-lg shadow-xl border z-50 w-96 ${
                                isDarkMode 
                                  ? 'bg-gray-900 border-gray-700 text-gray-200' 
                                  : 'bg-white border-gray-200 text-gray-800'
                              }`}>
                                <p className="text-sm leading-relaxed">{child.snippet}</p>
                              </div>
                            )}
                          </div>
                        </div>
                        <div className={`text-xs mt-0.5 pl-11 ${isDarkMode ? 'text-gray-500' : 'text-gray-500'}`}>
                          {child.source} • {child.sourceType === 'print' ? 'Print' : 'Online'}
                        </div>
                      </td>
                      <td className={`px-3 py-2 text-xs text-center ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        -
                      </td>
                      <td className={`px-3 py-2 text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-gray-200 rounded-full h-1.5 max-w-[60px]">
                            <div 
                              className={`h-1.5 rounded-full ${
                                child.confidenceScore >= 85 
                                  ? 'bg-green-500' 
                                  : child.confidenceScore >= 50
                                  ? 'bg-yellow-500'
                                  : 'bg-red-500'
                              }`}
                              style={{ width: `${child.confidenceScore}%` }}
                            />
                          </div>
                          <span className="font-medium min-w-[2rem] text-right">{child.confidenceScore}%</span>
                        </div>
                      </td>
                      <td className={`px-3 py-2 text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        {new Date(child.date).toLocaleDateString('nl-NL')}
                      </td>
                    </tr>
                  );
                });
              }

              return rows;
            })
          )}
        </tbody>
      </table>
      </div>
    </div>
  );
}