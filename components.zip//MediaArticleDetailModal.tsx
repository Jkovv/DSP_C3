import { X, ExternalLink, Calendar, Hash, FileText, Link as LinkIcon, Newspaper, BookOpen, ArrowLeft } from "lucide-react";

interface MediaArticle {
  id: string;
  title: string;
  source: string;
  sourceType: string;
  date: string;
  cbsArticle: string;
  snippet: string;
  content: string;
  link: string;
  page?: string;
  edition?: string;
}

interface MediaArticleDetailModalProps {
  article: MediaArticle | null;
  onClose: () => void;
  isDarkMode: boolean;
  onBack?: () => void;
  onCbsArticleClick?: (cbsArticleTitle: string) => void;
}

export function MediaArticleDetailModal({ article, onClose, isDarkMode, onBack, onCbsArticleClick }: MediaArticleDetailModalProps) {
  if (!article) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-8"
        onClick={onClose}
      >
        {/* Modal */}
        <div
          className={`w-full max-w-4xl max-h-[90vh] overflow-hidden rounded shadow-xl ${
            isDarkMode ? 'bg-gray-800' : 'bg-white'
          }`}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className={`p-6 border-b ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-3 flex-1">
                {onBack && (
                  <button
                    onClick={onBack}
                    className={`p-2 rounded transition-colors mt-0.5 ${
                      isDarkMode ? 'hover:bg-gray-700 text-white' : 'hover:bg-gray-100'
                    }`}
                    title="Terug naar CBS artikel"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </button>
                )}
                <div className="flex-1">
                  <h2 className={`text-xl font-medium mb-3 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    {article.title}
                  </h2>
                  <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar className={`w-4 h-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                      <span className={isDarkMode ? 'text-gray-300' : 'text-gray-700'}>
                        {new Date(article.date).toLocaleDateString('nl-NL', { 
                          day: 'numeric', 
                          month: 'long', 
                          year: 'numeric' 
                        })}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Newspaper className={`w-4 h-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                      <span className={isDarkMode ? 'text-gray-300' : 'text-gray-700'}>
                        {article.source}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <FileText className={`w-4 h-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                      <span className={isDarkMode ? 'text-gray-300' : 'text-gray-700'}>
                        {article.sourceType}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <button
                onClick={onClose}
                className={`p-2 rounded transition-colors ${
                  isDarkMode ? 'hover:bg-gray-700 text-white' : 'hover:bg-gray-100'
                }`}
                style={{ visibility: onBack ? 'hidden' : 'visible' }}
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="p-6 overflow-y-auto max-h-[calc(90vh-180px)]">
            {/* Metadata Grid */}
            <div className={`grid grid-cols-2 gap-4 mb-6 p-4 rounded ${
              isDarkMode ? 'bg-gray-700' : 'bg-gray-50'
            }`}>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Hash className={`w-4 h-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                  <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    ID
                  </span>
                </div>
                <div className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {article.id}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 mb-1">
                  <LinkIcon className={`w-4 h-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                  <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    Gekoppeld CBS artikel
                  </span>
                </div>
                <button
                  onClick={() => {
                    onCbsArticleClick?.(article.cbsArticle);
                  }}
                  className={`text-sm font-medium text-blue-500 hover:text-blue-600 hover:underline text-left ${isDarkMode ? 'text-blue-400 hover:text-blue-300' : ''}`}
                >
                  {article.cbsArticle}
                </button>
              </div>

              {article.page && (
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <BookOpen className={`w-4 h-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                    <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      Pagina
                    </span>
                  </div>
                  <div className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    {article.page}
                  </div>
                </div>
              )}

              {article.edition && (
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Newspaper className={`w-4 h-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                    <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      Editie
                    </span>
                  </div>
                  <div className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    {article.edition}
                  </div>
                </div>
              )}
            </div>

            {/* Snippet */}
            <div className="mb-6">
              <h3 className={`text-sm font-medium mb-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                Samenvatting
              </h3>
              <p className={`text-sm leading-relaxed ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {article.snippet}
              </p>
            </div>

            {/* Full Content */}
            <div className="mb-6">
              <h3 className={`text-sm font-medium mb-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                Volledige inhoud
              </h3>
              <div className={`text-sm leading-relaxed whitespace-pre-wrap ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {article.content}
              </div>
            </div>

            {/* Link to Original */}
            <div>
              <h3 className={`text-sm font-medium mb-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                Bron
              </h3>
              <a
                href={article.link}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-sm text-blue-500 hover:text-blue-600 hover:underline"
              >
                <ExternalLink className="w-4 h-4" />
                Bekijk origineel artikel
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}