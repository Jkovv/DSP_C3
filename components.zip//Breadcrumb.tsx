import { ChevronRight } from "lucide-react";

interface BreadcrumbItem {
  label: string;
  onClick?: () => void;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
  isDarkMode?: boolean;
}

export function Breadcrumb({ items, isDarkMode = false }: BreadcrumbProps) {
  return (
    <nav className="flex items-center space-x-2 text-sm">
      {items.map((item, index) => (
        <div key={index} className="flex items-center">
          {index > 0 && (
            <ChevronRight className={`w-4 h-4 mx-2 ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`} />
          )}
          {item.onClick ? (
            <button
              onClick={item.onClick}
              className={isDarkMode ? 'text-[#4db3d3] hover:underline' : 'text-[#005470] hover:underline'}
            >
              {item.label}
            </button>
          ) : (
            <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>{item.label}</span>
          )}
        </div>
      ))}
    </nav>
  );
}