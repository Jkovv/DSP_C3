import { useState, useEffect, useRef } from "react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Newspaper } from "lucide-react";

interface MediaArticle {
  id: string;
  title: string;
  source: string;
  sourceType: string;
  date: string;
  cbsArticle: string;
  snippet: string;
  content: string;
  link: string;
  page?: string;
  edition?: string;
}

interface Article {
  id: string;
  title: string;
  date: string;
  category: string;
  summary?: string;
}

interface RecentArticlesProps {
  articles: Article[];
  title?: string;
  onSeeAll?: () => void;
  fullHeight?: boolean;
  isDarkMode?: boolean;
  onArticleClick?: (article: Article) => void;
}

export function RecentArticles({ articles, title = "Recent gepubliceerde artikelen", onSeeAll, fullHeight = false, isDarkMode = false, onArticleClick }: RecentArticlesProps) {
  const [visibleCount, setVisibleCount] = useState(articles.length);
  const [measuring, setMeasuring] = useState(fullHeight);
  const containerRef = useRef<HTMLDivElement>(null);
  const itemRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    if (!fullHeight || !containerRef.current) return;

    // Wait for next frame to ensure all items are rendered
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        if (!containerRef.current) return;

        const container = containerRef.current;
        const containerHeight = container.clientHeight;
        const spacing = 8; // space-y-2 = 0.5rem = 8px
        let accumulatedHeight = 0;
        let count = 0;

        for (let i = 0; i < itemRefs.current.length; i++) {
          const item = itemRefs.current[i];
          if (!item) continue;

          const itemHeight = item.offsetHeight;
          const totalHeight = accumulatedHeight + itemHeight + (count > 0 ? spacing : 0);
          
          if (totalHeight <= containerHeight) {
            accumulatedHeight = totalHeight;
            count++;
          } else {
            break;
          }
        }

        setVisibleCount(count);
        setMeasuring(false);
      });
    });
  }, [fullHeight, articles.length]);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Arbeid en inkomen":
        return "bg-[#0580a1] text-white";
      case "Economie":
        return "bg-[#271D6C] text-white";
      case "Maatschappij":
        return "bg-[#af0e80] text-white";
      default:
        return "bg-gray-200 text-gray-800";
    }
  };

  return (
    <Card className={`border-2 w-full h-full flex flex-col overflow-hidden rounded ${isDarkMode ? 'bg-gray-800 border-gray-700' : ''}`}>
      <div className="flex items-center justify-between px-5 py-2 rounded-t" style={{ backgroundColor: '#0580a1' }}>
        <h3 className="text-white mb-0">{title}</h3>
        {onSeeAll && (
          <Button 
            onClick={onSeeAll}
            className="h-6 px-2 text-xs whitespace-nowrap rounded transition-all border"
            style={{ backgroundColor: '#ffffff', color: '#005470', borderColor: '#005470' }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = '#005470';
              e.currentTarget.style.color = '#ffffff';
              e.currentTarget.style.borderColor = '#005470';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = '#ffffff';
              e.currentTarget.style.color = '#005470';
              e.currentTarget.style.borderColor = '#005470';
            }}
          >
            Zie alles
          </Button>
        )}
      </div>
      <div 
        ref={containerRef}
        className={`px-4 -mt-2 ${fullHeight ? 'flex-1 overflow-y-auto' : 'pb-3'}`}
      >
        <div className="space-y-2">
          {articles.slice(0, 12).map((article, index) => (
            <div
              key={article.id}
              ref={(el) => (itemRefs.current[index] = el)}
              className={`pb-2 border-b last:border-b-0 cursor-pointer transition-colors ${
                isDarkMode 
                  ? 'border-gray-700 hover:bg-gray-700/50' 
                  : 'border-gray-200 hover:bg-gray-50'
              }`}
              onClick={() => onArticleClick?.(article)}
            >
              <div className="flex items-start gap-2 mb-2">
                <div className="flex-1">
                  <div className={`text-sm ${isDarkMode ? 'text-gray-100' : ''}`}>
                    {article.title}
                  </div>
                  {article.summary && (
                    <div className={`text-xs mt-1 line-clamp-2 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      {article.summary}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{article.date}</span>
                <span className={`text-xs ${isDarkMode ? 'text-gray-600' : 'text-gray-300'}`}>•</span>
                <div className="flex items-center gap-1">
                  <Newspaper className={`w-3 h-3 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                  <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    {Math.floor(Math.random() * 8) + 1} citaties
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={`${getCategoryColor(article.category)} text-xs px-2 py-0`}>
                  {article.category}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}