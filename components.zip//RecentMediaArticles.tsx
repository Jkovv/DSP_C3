import { Card } from "./ui/card";
import { Button } from "./ui/button";

interface MediaArticle {
  id: string;
  title: string;
  source: string;
  sourceType: string;
  date: string;
  cbsArticle: string;
  snippet: string;
  content: string;
  link: string;
  page?: string;
  edition?: string;
}

interface RecentMediaArticlesProps {
  articles: MediaArticle[];
  onSeeAll?: () => void;
  isDarkMode?: boolean;
  onArticleClick?: (article: MediaArticle) => void;
}

export function RecentMediaArticles({ articles, onSeeAll, isDarkMode = false, onArticleClick }: RecentMediaArticlesProps) {
  // Limit to 12 articles
  const displayArticles = articles.slice(0, 12);

  return (
    <Card className={`border-2 w-full h-full flex flex-col overflow-hidden rounded ${isDarkMode ? 'bg-gray-800 border-gray-700' : ''}`}>
      <div className="flex items-center justify-between px-5 py-2 rounded-t" style={{ backgroundColor: '#0580a1' }}>
        <h3 className="text-white mb-0">Recente media artikelen</h3>
        {onSeeAll && (
          <Button 
            onClick={onSeeAll}
            className="h-6 px-2 text-xs whitespace-nowrap rounded transition-all border"
            style={{ backgroundColor: '#ffffff', color: '#005470', borderColor: '#005470' }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = '#005470';
              e.currentTarget.style.color = '#ffffff';
              e.currentTarget.style.borderColor = '#005470';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = '#ffffff';
              e.currentTarget.style.color = '#005470';
              e.currentTarget.style.borderColor = '#005470';
            }}
          >
            Zie alles
          </Button>
        )}
      </div>
      <style>{`
        .recent-media-articles-scroll {
          overflow-y: scroll !important;
        }
        .recent-media-articles-scroll::-webkit-scrollbar {
          width: 8px;
          display: block !important;
        }
        .recent-media-articles-scroll::-webkit-scrollbar-track {
          background: ${isDarkMode ? '#1f2937' : '#f1f5f9'};
          border-radius: 4px;
        }
        .recent-media-articles-scroll::-webkit-scrollbar-thumb {
          background: ${isDarkMode ? '#4b5563' : '#cbd5e1'};
          border-radius: 4px;
          min-height: 40px;
        }
        .recent-media-articles-scroll::-webkit-scrollbar-thumb:hover {
          background: ${isDarkMode ? '#6b7280' : '#94a3b8'};
        }
      `}</style>
      <div 
        className="flex-1 px-4 pb-4 recent-media-articles-scroll -mt-2"
        style={{
          overflowY: 'scroll',
          scrollbarWidth: 'thin',
          scrollbarColor: isDarkMode ? '#4b5563 #1f2937' : '#cbd5e1 #f1f5f9'
        }}
      >
        <div className="space-y-2">
          {displayArticles.map((article) => (
            <div
              key={article.id}
              className={`pb-2 border-b last:border-b-0 ${
                isDarkMode ? 'border-gray-700' : 'border-gray-200'
              } ${onArticleClick ? 'cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50 -mx-2 px-2 rounded transition-colors' : ''}`}
              onClick={() => onArticleClick?.(article)}
            >
              <div className="flex items-start gap-2 mb-2">
                <div className="flex-1">
                  <div className={`text-sm ${isDarkMode ? 'text-gray-100' : ''}`}>
                    {article.title}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className={`text-xs ${isDarkMode ? 'text-[#4db3d3]' : ''}`} style={!isDarkMode ? { color: 'var(--cbs-dark-blue)' } : {}}>
                  {article.source}
                </span>
                <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{article.date}</span>
              </div>
              <div>
                <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  Citeert: <span className="italic">{article.cbsArticle}</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}