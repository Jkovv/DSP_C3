import { X, ChevronDown } from "lucide-react";
import { Button } from "./ui/button";
import { Checkbox } from "./ui/checkbox";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "./ui/collapsible";
import { useState, useEffect } from "react";

interface FilterSidebarProps {
  open: boolean;
  onClose: () => void;
  onApplyFilters: (filters: FilterState | MediaFilterState) => void;
  mode?: "cbs" | "media";
  isDarkMode?: boolean;
}

export interface FilterState {
  categories: {
    arbeid: boolean;
    economie: boolean;
    maatschappij: boolean;
  };
  subcategories: {
    // Arbeid en inkomen
    "Arbeid en sociale zekerheid": boolean;
    "Inkomen en bestedingen": boolean;
    // Economie
    "Bedrijven": boolean;
    "Bouwen en wonen": boolean;
    "Financiële en zakelijke diensten": boolean;
    "Handel en horeca": boolean;
    "Industrie en energie": boolean;
    "Internationale handel": boolean;
    "Landbouw": boolean;
    "Macro-economie": boolean;
    "Overheid en politiek": boolean;
    "Prijzen": boolean;
    // Maatschappij
    "Bevolking": boolean;
    "Gezondheid en welzijn": boolean;
    "Natuur en milieu": boolean;
    "Onderwijs": boolean;
    "Veiligheid en recht": boolean;
    "Verkeer en vervoer": boolean;
    "Vrije tijd en cultuur": boolean;
  };
  startDate: string;
  endDate: string;
  sortBy: "relevance" | "newest" | "oldest";
}

export interface MediaFilterState {
  sourceTypes: {
    print: boolean;
    online: boolean;
    rtv: boolean;
  };
  sources: {
    "De Telegraaf": boolean;
    "Trouw": boolean;
    "Het Financieele Dagblad": boolean;
    "NRC": boolean;
    "De Volkskrant": boolean;
    "AD": boolean;
    "NOS": boolean;
    "RTL Nieuws": boolean;
    "BNR Nieuwsradio": boolean;
  };
  startDate: string;
  endDate: string;
  sortBy: "relevance" | "newest" | "oldest";
}

const initialFilterState: FilterState = {
  categories: {
    arbeid: false,
    economie: false,
    maatschappij: false,
  },
  subcategories: {
    "Arbeid en sociale zekerheid": false,
    "Inkomen en bestedingen": false,
    "Bedrijven": false,
    "Bouwen en wonen": false,
    "Financiële en zakelijke diensten": false,
    "Handel en horeca": false,
    "Industrie en energie": false,
    "Internationale handel": false,
    "Landbouw": false,
    "Macro-economie": false,
    "Overheid en politiek": false,
    "Prijzen": false,
    "Bevolking": false,
    "Gezondheid en welzijn": false,
    "Natuur en milieu": false,
    "Onderwijs": false,
    "Veiligheid en recht": false,
    "Verkeer en vervoer": false,
    "Vrije tijd en cultuur": false,
  },
  startDate: "",
  endDate: "",
  sortBy: "relevance",
};

const initialMediaFilterState: MediaFilterState = {
  sourceTypes: {
    print: false,
    online: false,
    rtv: false,
  },
  sources: {
    "De Telegraaf": false,
    "Trouw": false,
    "Het Financieele Dagblad": false,
    "NRC": false,
    "De Volkskrant": false,
    "AD": false,
    "NOS": false,
    "RTL Nieuws": false,
    "BNR Nieuwsradio": false,
  },
  startDate: "",
  endDate: "",
  sortBy: "relevance",
};

export function FilterSidebar({ open, onClose, onApplyFilters, mode = "cbs", isDarkMode = false }: FilterSidebarProps) {
  const [cbsFilters, setCbsFilters] = useState<FilterState>(initialFilterState);
  const [mediaFilters, setMediaFilters] = useState<MediaFilterState>(initialMediaFilterState);
  const [sortOpen, setSortOpen] = useState(true);
  const [dateOpen, setDateOpen] = useState(true);
  const [categoriesOpen, setCategoriesOpen] = useState(true);

  const filters = mode === "cbs" ? cbsFilters : mediaFilters;
  const setFilters = mode === "cbs" ? setCbsFilters : setMediaFilters;

  if (!open) return null;

  const categoryData = {
    "Arbeid en inkomen": {
      key: "arbeid" as const,
      subcategories: [
        "Arbeid en sociale zekerheid",
        "Inkomen en bestedingen",
      ],
      color: "#0580a1",
    },
    "Economie": {
      key: "economie" as const,
      subcategories: [
        "Bedrijven",
        "Bouwen en wonen",
        "Financiële en zakelijke diensten",
        "Handel en horeca",
        "Industrie en energie",
        "Internationale handel",
        "Landbouw",
        "Macro-economie",
        "Overheid en politiek",
        "Prijzen",
      ],
      color: "#271D6C",
    },
    "Maatschappij": {
      key: "maatschappij" as const,
      subcategories: [
        "Bevolking",
        "Gezondheid en welzijn",
        "Natuur en milieu",
        "Onderwijs",
        "Veiligheid en recht",
        "Verkeer en vervoer",
        "Vrije tijd en cultuur",
      ],
      color: "#af0e80",
    },
  };

  const mediaSourceTypeData = {
    "Print": {
      key: "print" as const,
      sources: [
        "De Telegraaf",
        "Trouw",
        "Het Financieele Dagblad",
        "NRC",
        "De Volkskrant",
        "AD",
      ],
      color: "#0580a1",
    },
    "Online": {
      key: "online" as const,
      sources: [
        "NOS",
        "RTL Nieuws",
      ],
      color: "#271D6C",
    },
    "RTV": {
      key: "rtv" as const,
      sources: [
        "BNR Nieuwsradio",
      ],
      color: "#af0e80",
    },
  };

  const handleApply = () => {
    onApplyFilters(filters);
    onClose();
  };

  const handleReset = () => {
    if (mode === "cbs") {
      setCbsFilters(initialFilterState);
    } else {
      setMediaFilters(initialMediaFilterState);
    }
  };

  const handleSelectAll = () => {
    if (mode === "cbs") {
      setCbsFilters({
        ...cbsFilters,
        categories: {
          arbeid: true,
          economie: true,
          maatschappij: true,
        },
        subcategories: Object.keys(cbsFilters.subcategories).reduce((acc, key) => {
          acc[key as keyof typeof cbsFilters.subcategories] = true;
          return acc;
        }, {} as typeof cbsFilters.subcategories),
      });
    } else {
      setMediaFilters({
        ...mediaFilters,
        sourceTypes: {
          print: true,
          online: true,
          rtv: true,
        },
        sources: Object.keys(mediaFilters.sources).reduce((acc, key) => {
          acc[key] = true;
          return acc;
        }, {} as typeof mediaFilters.sources),
      });
    }
  };

  const handleDeselectAll = () => {
    if (mode === "cbs") {
      setCbsFilters({
        ...cbsFilters,
        categories: {
          arbeid: false,
          economie: false,
          maatschappij: false,
        },
        subcategories: Object.keys(cbsFilters.subcategories).reduce((acc, key) => {
          acc[key as keyof typeof cbsFilters.subcategories] = false;
          return acc;
        }, {} as typeof cbsFilters.subcategories),
      });
    } else {
      setMediaFilters({
        ...mediaFilters,
        sourceTypes: {
          print: false,
          online: false,
          rtv: false,
        },
        sources: Object.keys(mediaFilters.sources).reduce((acc, key) => {
          acc[key] = false;
          return acc;
        }, {} as typeof mediaFilters.sources),
      });
    }
  };

  const handleCategoryChange = (categoryKey: keyof FilterState["categories"], checked: boolean) => {
    const category = Object.values(categoryData).find(cat => cat.key === categoryKey);
    if (!category) return;

    const updatedSubcategories = { ...cbsFilters.subcategories };
    category.subcategories.forEach(subcat => {
      updatedSubcategories[subcat as keyof typeof cbsFilters.subcategories] = checked;
    });

    setCbsFilters({
      ...cbsFilters,
      categories: {
        ...cbsFilters.categories,
        [categoryKey]: checked,
      },
      subcategories: updatedSubcategories,
    });
  };

  const handleSourceTypeChange = (sourceTypeKey: keyof MediaFilterState["sourceTypes"], checked: boolean) => {
    const sourceType = Object.values(mediaSourceTypeData).find(st => st.key === sourceTypeKey);
    if (!sourceType) return;

    const updatedSources = { ...mediaFilters.sources };
    sourceType.sources.forEach(source => {
      updatedSources[source as keyof typeof mediaFilters.sources] = checked;
    });

    setMediaFilters({
      ...mediaFilters,
      sourceTypes: {
        ...mediaFilters.sourceTypes,
        [sourceTypeKey]: checked,
      },
      sources: updatedSources,
    });
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 z-40"
        onClick={onClose}
      />
      
      {/* Sidebar */}
      <div className={`fixed right-0 top-0 h-full w-[400px] shadow-lg z-50 flex flex-col ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}>
        {/* Header */}
        <div className={`p-6 border-b flex-shrink-0 ${isDarkMode ? 'bg-gray-700 border-gray-600' : 'bg-gray-100 border-gray-200'}`}>
          <div className="flex items-center justify-between">
            <div>
              <h3 className={`mb-1 ${isDarkMode ? 'text-white' : ''}`}>
                {mode === "cbs" ? "CBS Artikelen Filters" : "Media Artikelen Filters"}
              </h3>
              <p className={`text-xs mb-0 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                {mode === "cbs" 
                  ? "Filter CBS publicaties op categorie en periode" 
                  : "Filter media artikelen op bron en periode"}
              </p>
            </div>
            <button
              onClick={onClose}
              className={`p-1 rounded ${isDarkMode ? 'hover:bg-gray-600 text-white' : 'hover:bg-gray-200'}`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="space-y-4">
            {/* Sort */}
            <Collapsible open={sortOpen} onOpenChange={setSortOpen}>
              <CollapsibleTrigger className={`flex items-center justify-between w-full py-2 -mx-2 px-2 rounded ${isDarkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-50'}`}>
                <h4 className={`mb-0 ${isDarkMode ? 'text-white' : ''}`}>Sorteren op</h4>
                <ChevronDown className={`w-4 h-4 transition-transform ${sortOpen ? 'rotate-180' : ''} ${isDarkMode ? 'text-white' : ''}`} />
              </CollapsibleTrigger>
              <CollapsibleContent className="pt-3">
                <Select
                  value={filters.sortBy}
                  onValueChange={(value) =>
                    setFilters({ ...filters, sortBy: value as typeof filters.sortBy })
                  }
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Selecteer een optie" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="relevance">Relevantie</SelectItem>
                    <SelectItem value="newest">Nieuwste eerst</SelectItem>
                    <SelectItem value="oldest">Oudste eerst</SelectItem>
                  </SelectContent>
                </Select>
              </CollapsibleContent>
            </Collapsible>

            {/* Date Range Filter */}
            <Collapsible open={dateOpen} onOpenChange={setDateOpen}>
              <CollapsibleTrigger className={`flex items-center justify-between w-full py-2 -mx-2 px-2 rounded ${isDarkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-50'}`}>
                <h4 className={`mb-0 ${isDarkMode ? 'text-white' : ''}`}>Publicatiedatum</h4>
                <ChevronDown className={`w-4 h-4 transition-transform ${dateOpen ? 'rotate-180' : ''} ${isDarkMode ? 'text-white' : ''}`} />
              </CollapsibleTrigger>
              <CollapsibleContent className="pt-3">
                <div className="space-y-3">
                  <div className="flex-1">
                    <Label htmlFor="startDate" className={`text-sm mb-1 block ${isDarkMode ? 'text-gray-300' : ''}`}>
                      Van
                    </Label>
                    <input
                      type="date"
                      id="startDate"
                      value={filters.startDate}
                      onChange={(e) =>
                        setFilters({ ...filters, startDate: e.target.value })
                      }
                      className={`w-full px-3 py-2 border rounded text-sm cursor-pointer ${isDarkMode ? 'bg-gray-700 border-gray-600 text-white [color-scheme:dark]' : 'border-gray-300 [color-scheme:light]'}`}
                      style={{
                        WebkitAppearance: 'none',
                        MozAppearance: 'textfield',
                      }}
                    />
                  </div>
                  <div className="flex-1">
                    <Label htmlFor="endDate" className={`text-sm mb-1 block ${isDarkMode ? 'text-gray-300' : ''}`}>
                      Tot
                    </Label>
                    <input
                      type="date"
                      id="endDate"
                      value={filters.endDate}
                      onChange={(e) =>
                        setFilters({ ...filters, endDate: e.target.value })
                      }
                      className={`w-full px-3 py-2 border rounded text-sm cursor-pointer ${isDarkMode ? 'bg-gray-700 border-gray-600 text-white [color-scheme:dark]' : 'border-gray-300 [color-scheme:light]'}`}
                      style={{
                        WebkitAppearance: 'none',
                        MozAppearance: 'textfield',
                      }}
                    />
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>

            {/* CBS Categories or Media Sources */}
            {mode === "cbs" ? (
              <Collapsible open={categoriesOpen} onOpenChange={setCategoriesOpen}>
                <CollapsibleTrigger className={`flex items-center justify-between w-full py-2 -mx-2 px-2 rounded ${isDarkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-50'}`}>
                  <h4 className={`mb-0 ${isDarkMode ? 'text-white' : ''}`}>Categorieën</h4>
                  <ChevronDown className={`w-4 h-4 transition-transform ${categoriesOpen ? 'rotate-180' : ''} ${isDarkMode ? 'text-white' : ''}`} />
                </CollapsibleTrigger>
                <CollapsibleContent className="pt-3">
                  <div className={`flex gap-1.5 text-[10px] mb-3 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    <button
                      onClick={handleSelectAll}
                      className="hover:underline"
                    >
                      Selecteer alles
                    </button>
                    <span>|</span>
                    <button
                      onClick={handleDeselectAll}
                      className="hover:underline"
                    >
                      Deselecteer alles
                    </button>
                  </div>
                  
                  {Object.entries(categoryData).map(([categoryName, categoryInfo]) => (
                    <div key={categoryName} className="mb-4">
                      <div className="flex items-center space-x-2 mb-2">
                        <Checkbox
                          id={categoryInfo.key}
                          checked={cbsFilters.categories[categoryInfo.key]}
                          onCheckedChange={(checked) =>
                            handleCategoryChange(categoryInfo.key, checked as boolean)
                          }
                        />
                        <Label
                          htmlFor={categoryInfo.key}
                          className="cursor-pointer"
                          style={{ color: categoryInfo.color }}
                        >
                          {categoryName}
                        </Label>
                      </div>
                      
                      {/* Subcategories */}
                      <div className="ml-6 space-y-2">
                        {categoryInfo.subcategories.map((subcat) => (
                          <div key={subcat} className="flex items-center space-x-2">
                            <Checkbox
                              id={subcat}
                              checked={cbsFilters.subcategories[subcat as keyof typeof cbsFilters.subcategories]}
                              onCheckedChange={(checked) =>
                                setCbsFilters({
                                  ...cbsFilters,
                                  subcategories: {
                                    ...cbsFilters.subcategories,
                                    [subcat]: checked as boolean,
                                  },
                                })
                              }
                            />
                            <Label
                              htmlFor={subcat}
                              className="text-sm cursor-pointer"
                            >
                              {subcat}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </CollapsibleContent>
              </Collapsible>
            ) : (
              <Collapsible open={categoriesOpen} onOpenChange={setCategoriesOpen}>
                <CollapsibleTrigger className={`flex items-center justify-between w-full py-2 -mx-2 px-2 rounded ${isDarkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-50'}`}>
                  <h4 className={`mb-0 ${isDarkMode ? 'text-white' : ''}`}>Brontype & Bron</h4>
                  <ChevronDown className={`w-4 h-4 transition-transform ${categoriesOpen ? 'rotate-180' : ''} ${isDarkMode ? 'text-white' : ''}`} />
                </CollapsibleTrigger>
                <CollapsibleContent className="pt-3">
                  <div className={`flex gap-1.5 text-[10px] mb-3 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    <button
                      onClick={handleSelectAll}
                      className="hover:underline"
                    >
                      Selecteer alles
                    </button>
                    <span>|</span>
                    <button
                      onClick={handleDeselectAll}
                      className="hover:underline"
                    >
                      Deselecteer alles
                    </button>
                  </div>
                  
                  {Object.entries(mediaSourceTypeData).map(([sourceTypeName, sourceTypeInfo]) => (
                    <div key={sourceTypeName} className="mb-4">
                      <div className="flex items-center space-x-2 mb-2">
                        <Checkbox
                          id={sourceTypeInfo.key}
                          checked={mediaFilters.sourceTypes[sourceTypeInfo.key]}
                          onCheckedChange={(checked) =>
                            handleSourceTypeChange(sourceTypeInfo.key, checked as boolean)
                          }
                        />
                        <Label
                          htmlFor={sourceTypeInfo.key}
                          className="cursor-pointer"
                          style={{ color: sourceTypeInfo.color }}
                        >
                          {sourceTypeName}
                        </Label>
                      </div>
                      
                      {/* Sources */}
                      <div className="ml-6 space-y-2">
                        {sourceTypeInfo.sources.map((source) => (
                          <div key={source} className="flex items-center space-x-2">
                            <Checkbox
                              id={source}
                              checked={mediaFilters.sources[source as keyof typeof mediaFilters.sources]}
                              onCheckedChange={(checked) =>
                                setMediaFilters({
                                  ...mediaFilters,
                                  sources: {
                                    ...mediaFilters.sources,
                                    [source]: checked as boolean,
                                  },
                                })
                              }
                            />
                            <Label
                              htmlFor={source}
                              className="text-sm cursor-pointer"
                            >
                              {source}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </CollapsibleContent>
              </Collapsible>
            )}
          </div>
        </div>

        {/* Fixed Action Buttons */}
        <div className={`p-6 border-t flex-shrink-0 ${isDarkMode ? 'border-gray-700 bg-gray-800' : 'border-gray-200 bg-white'}`}>
          <div className="flex gap-3">
            <Button
              onClick={handleReset}
              variant="outline"
              className="flex-1"
            >
              Reset
            </Button>
            <Button
              onClick={handleApply}
              className="flex-1 transition-all"
              style={{ backgroundColor: 'var(--cbs-aqua)' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#005470';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--cbs-aqua)';
              }}
            >
              Toepassen
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}