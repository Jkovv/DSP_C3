import { X, AlertCircle } from "lucide-react";
import React from "react";

interface SimilarArticle {
  id: string;
  title: string;
  source: string;
  confidenceScore: number;
  currentCbsArticle: string;
}

interface BulkReclassificationModalProps {
  open: boolean;
  onClose: () => void;
  onConfirm: (selectedArticleIds: string[]) => void;
  originalArticle: {
    title: string;
    oldCbsArticle: string;
    newCbsArticle: string;
  };
  similarArticles: SimilarArticle[];
  isDarkMode: boolean;
}

export function BulkReclassificationModal({
  open,
  onClose,
  onConfirm,
  originalArticle,
  similarArticles,
  isDarkMode
}: BulkReclassificationModalProps) {
  const [selectedArticles, setSelectedArticles] = React.useState<Set<string>>(new Set());

  React.useEffect(() => {
    // Auto-select all similar articles by default
    if (open) {
      setSelectedArticles(new Set(similarArticles.map(a => a.id)));
    }
  }, [open, similarArticles]);

  if (!open) return null;

  const handleToggle = (id: string) => {
    const newSelected = new Set(selectedArticles);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedArticles(newSelected);
  };

  const handleSelectAll = () => {
    setSelectedArticles(new Set(similarArticles.map(a => a.id)));
  };

  const handleDeselectAll = () => {
    setSelectedArticles(new Set());
  };

  const handleConfirm = () => {
    onConfirm(Array.from(selectedArticles));
    onClose();
  };

  const handleOnlyOriginal = () => {
    onConfirm([]);
    onClose();
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center"
        onClick={onClose}
      >
        {/* Modal */}
        <div
          className={`w-full max-w-3xl max-h-[80vh] overflow-hidden rounded-lg shadow-xl ${
            isDarkMode ? 'bg-gray-800' : 'bg-white'
          }`}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className={`p-6 border-b ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded bg-orange-100">
                  <AlertCircle className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <h3 className={`mb-1 ${isDarkMode ? 'text-white' : ''}`}>
                    Vergelijkbare Artikelen Gevonden
                  </h3>
                  <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    We hebben {similarArticles.length} vergelijkbare artikel(en) gevonden die mogelijk ook verkeerd geclassificeerd zijn
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className={`p-1 rounded ${isDarkMode ? 'hover:bg-gray-700 text-white' : 'hover:bg-gray-100'}`}
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Original Classification Change */}
          <div className={`p-6 border-b ${isDarkMode ? 'border-gray-700 bg-gray-700' : 'border-gray-200 bg-gray-50'}`}>
            <div className="text-sm">
              <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                U heeft <span className="font-medium">{originalArticle.title}</span> gematcht aan{' '}
              </span>
              <span className={`font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                {originalArticle.newCbsArticle}</span>
            </div>
          </div>

          {/* Similar Articles List */}
          <div className="p-6 overflow-y-auto max-h-[400px]">
            <div className="flex items-center justify-between mb-4">
              <h4 className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                Selecteer artikelen om ook te herclassificeren:
              </h4>
              <div className="flex gap-2 text-xs">
                <button
                  onClick={handleSelectAll}
                  className="text-blue-500 hover:underline"
                >
                  Selecteer alles
                </button>
                <span className={isDarkMode ? 'text-gray-600' : 'text-gray-400'}>|</span>
                <button
                  onClick={handleDeselectAll}
                  className="text-blue-500 hover:underline"
                >
                  Deselecteer alles
                </button>
              </div>
            </div>

            <div className="space-y-2">
              {similarArticles.map(article => (
                <label
                  key={article.id}
                  className={`flex items-start gap-3 p-3 rounded border cursor-pointer transition-colors ${
                    selectedArticles.has(article.id)
                      ? isDarkMode
                        ? 'border-blue-500 bg-blue-900/20'
                        : 'border-blue-500 bg-blue-50'
                      : isDarkMode
                        ? 'border-gray-700 hover:bg-gray-700'
                        : 'border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={selectedArticles.has(article.id)}
                    onChange={() => handleToggle(article.id)}
                    className="mt-1 rounded"
                  />
                  <div className="flex-1">
                    <div className={`text-sm font-medium mb-1 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      {article.title}
                    </div>
                    <div className="flex items-center gap-4 text-xs">
                      <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                        {article.source}
                      </span>
                      <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                        {article.currentCbsArticle}
                      </span>
                      <span className={`font-medium ${
                        article.confidenceScore < 80 
                          ? 'text-orange-500' 
                          : 'text-green-500'
                      }`}>
                        {article.confidenceScore}% betrouwbaarheid
                      </span>
                    </div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Footer */}
          <div className={`p-6 border-t ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
            <div className="flex items-center justify-between">
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {selectedArticles.size} van {similarArticles.length} artikel(en) geselecteerd
              </p>
              <div className="flex gap-3">
                <button
                  onClick={onClose}
                  className={`px-4 py-2 rounded border transition-colors ${
                    isDarkMode 
                      ? 'border-gray-600 text-gray-300 hover:bg-gray-700' 
                      : 'border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  Annuleren
                </button>
                <button
                  onClick={handleOnlyOriginal}
                  className={`px-4 py-2 rounded border transition-colors ${
                    isDarkMode 
                      ? 'border-gray-600 text-gray-300 hover:bg-gray-700' 
                      : 'border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  Alleen huidig artikel matchen
                </button>
                <button
                  onClick={handleConfirm}
                  className="px-4 py-2 rounded text-white transition-all"
                  style={{ backgroundColor: 'var(--cbs-aqua)' }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = '#005470';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = 'var(--cbs-aqua)';
                  }}
                >
                  Bevestig match voor {selectedArticles.size + 1} artikelen
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}