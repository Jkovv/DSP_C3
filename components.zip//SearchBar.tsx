import { Search } from "lucide-react";
import { Input } from "./ui/input";

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
}

export function SearchBar({ value, onChange }: SearchBarProps) {
  return (
    <div className="relative">
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-[#0580a1]" />
      <Input
        type="text"
        placeholder="Zoek artikelen..."
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="pl-10 bg-white border-[#0580a1] focus:border-[#0580a1] focus:ring-[#0580a1]"
      />
    </div>
  );
}