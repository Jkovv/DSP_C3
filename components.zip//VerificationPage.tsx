import { useState } from "react";
import { ArrowLeft, Moon, Sun, CheckCircle, AlertTriangle, Search, TrendingUp, Tag, X } from "lucide-react";
import { Breadcrumb } from "./Breadcrumb";
import { MediaArticleMatch } from "./MatchingPlatform";

interface VerificationPageProps {
  article: MediaArticleMatch;
  onBack: () => void;
  onBackToDashboard?: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onReclassify: (articleId: string, newCategory: string, newCbsArticle: string) => void;
}

export function VerificationPage({ 
  article, 
  onBack, 
  onBackToDashboard,
  isDarkMode, 
  onToggleDarkMode,
  onReclassify 
}: VerificationPageProps) {
  const [selectedCbsArticle, setSelectedCbsArticle] = useState(article.matchedCbsArticle);
  const [searchQuery, setSearchQuery] = useState("");
  const [showAllCbsArticles, setShowAllCbsArticles] = useState(false);
  
  // Mock CBS articles database with metadata
  const allCbsArticles = [
    { 
      id: "cbs1", 
      title: "Arbeidsmarkt Q4 2025", 
      category: "Arbeid en inkomen",
      keywords: ["werkloosheid", "arbeidsmarkt", "kwartaal", "banen"],
      publishDate: "2026-01-08"
    },
    { 
      id: "cbs2", 
      title: "Inflatie januari 2026", 
      category: "Prijzen",
      keywords: ["inflatie", "prijzen", "consument", "economie"],
      publishDate: "2026-01-14"
    },
    { 
      id: "cbs3", 
      title: "Bevolkingsontwikkeling 2025", 
      category: "Bevolking",
      keywords: ["bevolking", "groei", "demografie", "migratie"],
      publishDate: "2026-01-13"
    },
    { 
      id: "cbs4", 
      title: "Detailhandel december 2025", 
      category: "Handel en horeca",
      keywords: ["detailhandel", "omzet", "verkoop", "consumenten"],
      publishDate: "2026-01-07"
    },
    { 
      id: "cbs5", 
      title: "Woningmarkt 2025", 
      category: "Bouwen en wonen",
      keywords: ["woningmarkt", "huizenprijzen", "nieuwbouw", "hypotheek"],
      publishDate: "2026-01-10"
    },
    { 
      id: "cbs6", 
      title: "Verkeersdata december 2025", 
      category: "Verkeer en vervoer",
      keywords: ["verkeer", "auto's", "mobiliteit", "vervoer"],
      publishDate: "2026-01-05"
    },
    { 
      id: "cbs7", 
      title: "Landbouwexport 2025", 
      category: "Landbouw",
      keywords: ["landbouw", "export", "agrarisch", "voedsel"],
      publishDate: "2026-01-06"
    },
    { 
      id: "cbs8", 
      title: "Zorguitgaven 2025", 
      category: "Gezondheid en welzijn",
      keywords: ["zorg", "gezondheid", "uitgaven", "gezondheidszorg"],
      publishDate: "2026-01-11"
    },
    { 
      id: "cbs9", 
      title: "Veiligheidsmonitor 2025", 
      category: "Veiligheid en recht",
      keywords: ["criminaliteit", "veiligheid", "misdaad", "politie"],
      publishDate: "2026-01-03"
    },
    { 
      id: "cbs10", 
      title: "Energiemarkt Q4 2025", 
      category: "Industrie en energie",
      keywords: ["energie", "gas", "elektriciteit", "duurzaam"],
      publishDate: "2026-01-09"
    },
    { 
      id: "cbs11", 
      title: "Onderwijsmonitor 2025", 
      category: "Onderwijs",
      keywords: ["onderwijs", "scholieren", "studenten", "school"],
      publishDate: "2026-01-12"
    },
    { 
      id: "cbs12", 
      title: "Bedrijvigheid Q1 2026", 
      category: "Bedrijven",
      keywords: ["bedrijven", "faillissementen", "ondernemingen", "economie"],
      publishDate: "2026-01-15"
    },
    { 
      id: "cbs13", 
      title: "Werkloosheid november 2025", 
      category: "Arbeid en inkomen",
      keywords: ["werkloosheid", "arbeidsmarkt", "banen", "vacatures"],
      publishDate: "2025-12-15"
    },
    { 
      id: "cbs14", 
      title: "Huizenprijzen december 2025", 
      category: "Bouwen en wonen",
      keywords: ["huizenprijzen", "woningmarkt", "vastgoed", "koopwoningen"],
      publishDate: "2026-01-08"
    },
    { 
      id: "cbs15", 
      title: "Consumentenprijzen december 2025", 
      category: "Prijzen",
      keywords: ["prijzen", "consumenten", "inflatie", "boodschappen"],
      publishDate: "2026-01-10"
    }
  ];

  // Calculate match scores for suggestions
  const calculateMatchScore = (cbsArticle: typeof allCbsArticles[0]) => {
    let score = 0;
    let reasons: string[] = [];
    
    // Keyword matching
    const matchingKeywords = cbsArticle.keywords.filter(keyword => 
      article.keyTerms.some(term => 
        term.toLowerCase().includes(keyword.toLowerCase()) || 
        keyword.toLowerCase().includes(term.toLowerCase())
      )
    );
    
    if (matchingKeywords.length > 0) {
      score += matchingKeywords.length * 25;
      reasons.push(`${matchingKeywords.length} matching terms`);
    }
    
    // Title similarity (simple word matching)
    const articleWords = article.title.toLowerCase().split(' ');
    const cbsWords = cbsArticle.title.toLowerCase().split(' ');
    const commonWords = articleWords.filter(word => 
      word.length > 3 && cbsWords.some(cbsWord => cbsWord.includes(word) || word.includes(cbsWord))
    );
    
    if (commonWords.length > 0) {
      score += commonWords.length * 20;
      reasons.push(`${commonWords.length} title words match`);
    }
    
    // Recent publication bonus
    const daysDiff = Math.abs(
      new Date(cbsArticle.publishDate).getTime() - new Date(article.date).getTime()
    ) / (1000 * 60 * 60 * 24);
    
    if (daysDiff < 7) {
      score += 15;
      reasons.push("Recent publication");
    }
    
    return { score, reasons, matchingKeywords };
  };

  // Get suggested matches
  const suggestedMatches = allCbsArticles
    .map(cbsArticle => ({
      ...cbsArticle,
      ...calculateMatchScore(cbsArticle)
    }))
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);

  // Filter CBS articles by search query
  const filteredCbsArticles = searchQuery.trim() 
    ? allCbsArticles.filter(cbsArticle => 
        cbsArticle.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        cbsArticle.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        cbsArticle.keywords.some(keyword => keyword.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : [];
  
  // Mock related articles with high confidence
  const relatedArticles = [
    {
      id: "r1",
      title: "Arbeidsmarkt stabiliseert in 2025",
      category: "Arbeid en inkomen",
      confidenceScore: 96,
      matchCount: 8
    },
    {
      id: "r2",
      title: "Woningbouw stagneert ondanks hoge vraag",
      category: "Bouwen en wonen",
      confidenceScore: 93,
      matchCount: 12
    },
    {
      id: "r3",
      title: "Consumentenprijzen stijgen minder hard",
      category: "Prijzen",
      confidenceScore: 98,
      matchCount: 15
    },
    {
      id: "r4",
      title: "Bedrijfsinvesteringen nemen toe in Q4",
      category: "Bedrijven",
      confidenceScore: 91,
      matchCount: 6
    },
    {
      id: "r5",
      title: "Mobiliteit neemt weer toe na corona",
      category: "Verkeer en vervoer",
      confidenceScore: 89,
      matchCount: 10
    }
  ];

  const categories = [
    "Arbeid en inkomen",
    "Bedrijven",
    "Bouwen en wonen",
    "Prijzen",
    "Bevolking",
    "Gezondheid en welzijn",
    "Onderwijs",
    "Veiligheid en recht",
    "Verkeer en vervoer",
    "Handel en horeca",
    "Landbouw",
    "Industrie en energie"
  ];

  const cbsArticlesByCategory: { [key: string]: string[] } = {
    "Arbeid en inkomen": ["Arbeidsmarkt Q4 2025", "Werkloosheid november 2025", "Loongroei 2025"],
    "Bedrijven": ["Bedrijvigheid Q1 2026", "Faillissementen 2025", "Bedrijfsvertrouwen januari 2026"],
    "Bouwen en wonen": ["Woningmarkt 2025", "Nieuwbouw Q4 2025", "Huizenprijzen december 2025"],
    "Prijzen": ["Inflatie januari 2026", "Consumentenprijzen december 2025", "Energieprijzen Q4 2025"],
    "Bevolking": ["Bevolkingsontwikkeling 2025", "Migratie 2025", "Geboorte en sterfte 2025"],
    "Gezondheid en welzijn": ["Zorguitgaven 2025", "Gezondheidsmonitor 2025", "Levensverwachting 2025"],
    "Onderwijs": ["Onderwijsmonitor 2025", "Studiesucces 2025", "Onderwijsuitgaven 2025"],
    "Veiligheid en recht": ["Veiligheidsmonitor 2025", "Criminaliteit 2025", "Rechtsgang 2025"],
    "Verkeer en vervoer": ["Verkeersdata december 2025", "Mobiliteit 2025", "Verkeersveiligheid 2025"],
    "Handel en horeca": ["Detailhandel december 2025", "Horeca-omzet 2025", "Online verkoop 2025"],
    "Landbouw": ["Landbouwexport 2025", "Agrarische productie 2025", "Veehouderij 2025"],
    "Industrie en energie": ["Energiemarkt Q4 2025", "Industriële productie 2025", "Hernieuwbare energie 2025"]
  };

  const highlightText = (text: string, terms: string[]) => {
    const segments: { text: string; highlight: boolean; isCbsLink?: boolean; cbsArticle?: string }[] = [];
    
    // First, identify CBS article references in the text
    const cbsLinkPatterns = [
      /rapport ['']([^'']+)['']/gi,
      /het CBS ([a-zA-Z\s]+)/gi,
    ];
    
    let lastIndex = 0;
    const allMatches: { start: number; end: number; type: 'highlight' | 'link'; value: string }[] = [];
    
    // Find all key term highlights
    terms.forEach(term => {
      const lowerText = text.toLowerCase();
      const lowerTerm = term.toLowerCase();
      let index = 0;
      while ((index = lowerText.indexOf(lowerTerm, index)) !== -1) {
        allMatches.push({
          start: index,
          end: index + term.length,
          type: 'highlight',
          value: term
        });
        index += term.length;
      }
    });
    
    // Find all CBS article references
    cbsLinkPatterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        const linkText = match[1] || match[0];
        allMatches.push({
          start: match.index,
          end: match.index + match[0].length,
          type: 'link',
          value: linkText
        });
      }
    });
    
    // Sort matches by start position
    allMatches.sort((a, b) => a.start - b.start);
    
    // Build segments
    let currentPos = 0;
    allMatches.forEach(match => {
      // Add text before match
      if (match.start > currentPos) {
        segments.push({
          text: text.substring(currentPos, match.start),
          highlight: false
        });
      }
      
      // Add the match
      if (match.type === 'highlight') {
        segments.push({
          text: text.substring(match.start, match.end),
          highlight: true
        });
      } else {
        segments.push({
          text: text.substring(match.start, match.end),
          highlight: false,
          isCbsLink: true,
          cbsArticle: match.value
        });
      }
      
      currentPos = Math.max(currentPos, match.end);
    });
    
    // Add remaining text
    if (currentPos < text.length) {
      segments.push({
        text: text.substring(currentPos),
        highlight: false
      });
    }
    
    return segments.length > 0 ? segments : [{ text, highlight: false }];
  };

  const textParts = highlightText(article.fullText, article.keyTerms);

  const handleCategoryChange = (category: string) => {
    // Reset CBS article selection when category changes
    const articlesForCategory = cbsArticlesByCategory[category] || [];
    setSelectedCbsArticle(articlesForCategory[0] || "");
  };

  const handleSubmitReclassification = () => {
    onReclassify(article.id, article.cbsCategory, selectedCbsArticle);
  };

  const hasChanges = selectedCbsArticle !== article.matchedCbsArticle;

  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
      {/* Top Bar */}
      <div className={`border-b sticky top-0 z-50 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white'}`}>
        <div className="max-w-[1880px] mx-auto px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={onBack}
                className={`p-2 rounded transition-all ${isDarkMode ? 'hover:bg-gray-700 text-white' : 'hover:bg-gray-100'}`}
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <Breadcrumb 
                items={[
                  { label: "Dashboard", onClick: onBackToDashboard },
                  { label: "Matching Platform", onClick: onBack },
                  { label: "Matching artikel" }
                ]}
                isDarkMode={isDarkMode}
              />
            </div>
            
            <button
              onClick={onToggleDarkMode}
              className="h-9 w-9 rounded text-white inline-flex items-center justify-center transition-all"
              style={{ backgroundColor: 'var(--cbs-aqua)' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#005470';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--cbs-aqua)';
              }}
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-[1880px] mx-auto px-8 py-8">
        <div className="grid grid-cols-3 gap-6">
          {/* Left Column - Article Content (2 columns width) */}
          <div className="col-span-2 space-y-6">
            {/* Article Header */}
            <div className={`p-6 rounded border ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h2 className={`mb-2 ${isDarkMode ? 'text-white' : ''}`}>{article.title}</h2>
                  <div className="flex items-center gap-4 text-sm">
                    <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                      Bron: <span className="font-medium">{article.source}</span>
                    </span>
                    <span className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                      {new Date(article.date).toLocaleDateString('nl-NL')}
                    </span>
                  </div>
                </div>
                
                {/* Confidence Score Badge */}
                <div className={`px-4 py-2 rounded border ${
                  article.confidenceScore < 80 
                    ? 'bg-orange-50 border-orange-200 text-orange-700'
                    : isDarkMode 
                      ? 'bg-green-900/20 border-green-700 text-green-400'
                      : 'bg-green-50 border-green-200 text-green-700'
                }`}>
                  <div className="flex items-center gap-2">
                    {article.confidenceScore < 80 ? (
                      <AlertTriangle className="w-4 h-4" />
                    ) : (
                      <CheckCircle className="w-4 h-4" />
                    )}
                    <div>
                      <div className="text-xs">Betrouwbaarheid</div>
                      <div className="text-lg font-semibold">{article.confidenceScore}%</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Current Classification */}
              <div className={`p-3 rounded ${isDarkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                <div className="text-sm">
                  <span className={`block mb-1 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    Gekoppeld aan:
                  </span>
                  <a
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      // Could navigate to CBS article detail here
                    }}
                    className={`font-medium text-blue-500 hover:text-blue-600 hover:underline`}
                    title={`Bekijk CBS artikel: ${article.matchedCbsArticle}`}
                  >
                    {article.matchedCbsArticle}
                  </a>
                </div>
              </div>

              {/* Key Terms */}
              <div className="mb-4">
                <h4 className={`mb-2 text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  Sleuteltermen voor classificatie:
                </h4>
                <div className="flex flex-wrap gap-2">
                  {article.keyTerms.map((term, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 rounded text-sm text-white"
                      style={{ backgroundColor: 'var(--cbs-aqua)' }}
                    >
                      {term}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Article Text */}
            <div className={`p-6 rounded border ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
              <h3 className={`mb-4 ${isDarkMode ? 'text-white' : ''}`}>Artikel Tekst</h3>
              <div className={`leading-relaxed whitespace-pre-wrap ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                {textParts.map((part, idx) => {
                  if (part.isCbsLink) {
                    return (
                      <a
                        key={idx}
                        href="#"
                        onClick={(e) => {
                          e.preventDefault();
                          // Could navigate to CBS article detail here
                        }}
                        className="text-blue-500 hover:text-blue-600 hover:underline"
                        title={`Bekijk CBS artikel: ${part.cbsArticle}`}
                      >
                        {part.text}
                      </a>
                    );
                  } else if (part.highlight) {
                    return (
                      <span
                        key={idx}
                        className="bg-yellow-200 text-gray-900 px-1 rounded"
                      >
                        {part.text}
                      </span>
                    );
                  } else {
                    return <span key={idx}>{part.text}</span>;
                  }
                })}
              </div>
            </div>
          </div>

          {/* Right Column - Match Correction */}
          <div className="col-span-1">
            <div className={`p-6 rounded border sticky top-24 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
              <h3 className={`mb-4 ${isDarkMode ? 'text-white' : ''}`}>Match Correctie</h3>
              
              {/* Search CBS Articles - Moved to top */}
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-3">
                  <Search className={`w-4 h-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
                  <h4 className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    Zoek CBS Artikel
                  </h4>
                </div>
                
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Zoek op titel, categorie of trefwoorden..."
                    className={`w-full px-3 py-2 pr-8 rounded border text-sm ${
                      isDarkMode 
                        ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400' 
                        : 'border-gray-300 placeholder-gray-500'
                    }`}
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery("")}
                      className={`absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded hover:bg-gray-200 ${
                        isDarkMode ? 'hover:bg-gray-600' : 'hover:bg-gray-200'
                      }`}
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
                
                {/* Search Results */}
                {searchQuery && filteredCbsArticles.length > 0 && (
                  <div className={`mt-2 max-h-64 overflow-y-auto rounded border ${
                    isDarkMode ? 'border-gray-700 bg-gray-700' : 'border-gray-200 bg-white'
                  }`}>
                    {filteredCbsArticles.map((cbsArticle) => (
                      <div
                        key={cbsArticle.id}
                        onClick={() => {
                          setSelectedCbsArticle(cbsArticle.title);
                          setSearchQuery("");
                        }}
                        className={`p-3 border-b last:border-b-0 cursor-pointer transition-colors ${
                          isDarkMode 
                            ? 'border-gray-600 hover:bg-gray-600' 
                            : 'border-gray-100 hover:bg-gray-50'
                        }`}
                      >
                        <div className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                          {cbsArticle.title}
                        </div>
                        <div className={`text-xs mt-1 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {new Date(cbsArticle.publishDate).toLocaleDateString('nl-NL')}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                
                {searchQuery && filteredCbsArticles.length === 0 && (
                  <div className={`mt-2 p-3 rounded border text-sm text-center ${
                    isDarkMode 
                      ? 'border-gray-700 bg-gray-700 text-gray-400' 
                      : 'border-gray-200 bg-gray-50 text-gray-600'
                  }`}>
                    Geen CBS artikelen gevonden
                  </div>
                )}
              </div>

              {/* Suggested Matches */}
              {suggestedMatches.length > 0 && (
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-3">
                    <TrendingUp className={`w-4 h-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
                    <h4 className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                      Voorgestelde Matches
                    </h4>
                  </div>
                  <p className={`text-xs mb-3 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    Gebaseerd op sleuteltermen en inhoud
                  </p>
                  
                  <div className="space-y-2 max-h-[400px] overflow-y-auto">
                    {suggestedMatches.map((suggestion) => (
                      <div
                        key={suggestion.id}
                        onClick={() => {
                          setSelectedCbsArticle(suggestion.title);
                        }}
                        className={`p-3 rounded border cursor-pointer transition-all ${
                          selectedCbsArticle === suggestion.title
                            ? isDarkMode
                              ? 'border-[var(--cbs-aqua)] bg-[var(--cbs-aqua)]/10'
                              : 'border-[var(--cbs-aqua)] bg-[var(--cbs-aqua)]/5'
                            : isDarkMode
                              ? 'border-gray-700 hover:border-gray-600 hover:bg-gray-700'
                              : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                              {suggestion.title}
                            </div>
                          </div>
                          <div className={`text-xs font-medium px-2 py-1 rounded ml-2 ${
                            isDarkMode ? 'bg-gray-700 text-green-400' : 'bg-green-50 text-green-700'
                          }`}>
                            {suggestion.score}%
                          </div>
                        </div>
                        
                        {/* Match reasons */}
                        <div className="flex flex-wrap gap-1 mt-2">
                          {suggestion.reasons.map((reason, idx) => (
                            <span
                              key={idx}
                              className={`text-xs px-2 py-0.5 rounded ${
                                isDarkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700'
                              }`}
                            >
                              {reason}
                            </span>
                          ))}
                        </div>
                        
                        {/* Matching keywords */}
                        {suggestion.matchingKeywords.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {suggestion.matchingKeywords.map((keyword, idx) => (
                              <span
                                key={idx}
                                className="text-xs px-2 py-0.5 rounded bg-yellow-100 text-yellow-800"
                              >
                                <Tag className="w-3 h-3 inline mr-1" />
                                {keyword}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Confirm Match Button - Bottom Right */}
              <div className="flex justify-end">
                <button
                  onClick={handleSubmitReclassification}
                  disabled={selectedCbsArticle === article.matchedCbsArticle}
                  className={`h-10 px-6 rounded text-sm text-white transition-all ${
                    selectedCbsArticle === article.matchedCbsArticle
                      ? 'opacity-50 cursor-not-allowed bg-gray-400'
                      : 'cursor-pointer'
                  }`}
                  style={{ 
                    backgroundColor: selectedCbsArticle === article.matchedCbsArticle ? '#9ca3af' : 'var(--cbs-aqua)' 
                  }}
                  onMouseEnter={(e) => {
                    if (selectedCbsArticle !== article.matchedCbsArticle) {
                      e.currentTarget.style.backgroundColor = '#005470';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (selectedCbsArticle !== article.matchedCbsArticle) {
                      e.currentTarget.style.backgroundColor = 'var(--cbs-aqua)';
                    }
                  }}
                >
                  <CheckCircle className="w-4 h-4 inline mr-2" />
                  Bevestig Match
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}