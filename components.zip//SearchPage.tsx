import { useState } from "react";
import { Search, SlidersHorizontal, Moon, Sun, ArrowLeft } from "lucide-react";
import { Button } from "./ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "./ui/tabs";
import { Card } from "./ui/card";
import { FilterSidebar, FilterState, MediaFilterState } from "./FilterSidebar";
import { Breadcrumb } from "./Breadcrumb";

interface Article {
  id: string;
  title: string;
  date: string;
  category: string;
  summary?: string;
}

interface MediaArticle {
  id: string;
  title: string;
  source: string;
  sourceType?: string;
  date: string;
  cbsArticle: string;
  url?: string;
}

interface SearchPageProps {
  onBack: () => void;
  cbsArticles: Article[];
  mediaArticles: MediaArticle[];
  tab?: "cbs" | "media";
  onTabChange?: (tab: "cbs" | "media") => void;
  isDarkMode?: boolean;
  onToggleDarkMode?: () => void;
  onCbsArticleClick?: (article: Article) => void;
  onMediaArticleClick?: (article: MediaArticle) => void;
}

export function SearchPage({ onBack, cbsArticles, mediaArticles, tab, onTabChange, isDarkMode = false, onToggleDarkMode, onCbsArticleClick, onMediaArticleClick }: SearchPageProps) {
  const [activeTab, setActiveTab] = useState<"cbs" | "media">(tab || "cbs");
  const [cbsSearchQuery, setCbsSearchQuery] = useState("");
  const [mediaSearchQuery, setMediaSearchQuery] = useState("");
  const [filterSidebarOpen, setFilterSidebarOpen] = useState(false);
  const [cbsFilters, setCbsFilters] = useState<FilterState | null>(null);
  const [mediaFilters, setMediaFilters] = useState<MediaFilterState | null>(null);

  const handleApplyCbsFilters = (newFilters: FilterState | MediaFilterState) => {
    if (activeTab === "cbs") {
      setCbsFilters(newFilters as FilterState);
    } else {
      setMediaFilters(newFilters as MediaFilterState);
    }
  };

  // Filter CBS articles
  let filteredCbsArticles = cbsArticles;
  if (cbsSearchQuery.trim()) {
    filteredCbsArticles = filteredCbsArticles.filter((article) =>
      article.title.toLowerCase().includes(cbsSearchQuery.toLowerCase()) ||
      article.category.toLowerCase().includes(cbsSearchQuery.toLowerCase()) ||
      article.summary?.toLowerCase().includes(cbsSearchQuery.toLowerCase())
    );
  }

  // Apply filters to CBS articles
  if (cbsFilters) {
    const hasAnyFilter = cbsFilters.categories.arbeid || cbsFilters.categories.economie || cbsFilters.categories.maatschappij;
    if (hasAnyFilter) {
      filteredCbsArticles = filteredCbsArticles.filter((article) => {
        if (cbsFilters.categories.arbeid && article.category.includes("Arbeid")) return true;
        if (cbsFilters.categories.economie && article.category.includes("Economie")) return true;
        if (cbsFilters.categories.maatschappij && article.category.includes("Maatschappij")) return true;
        return false;
      });
    }

    // Apply date filters
    if (cbsFilters.startDate || cbsFilters.endDate) {
      filteredCbsArticles = filteredCbsArticles.filter((article) => {
        // Parse article date (format: "22 nov 2025")
        const dateParts = article.date.split(' ');
        const months: { [key: string]: string } = {
          'jan': '01', 'feb': '02', 'mrt': '03', 'apr': '04', 'mei': '05', 'jun': '06',
          'jul': '07', 'aug': '08', 'sep': '09', 'okt': '10', 'nov': '11', 'dec': '12'
        };
        const month = months[dateParts[1]];
        const articleDate = new Date(`${dateParts[2]}-${month}-${dateParts[0]}`);
        
        if (cbsFilters.startDate) {
          const startDate = new Date(cbsFilters.startDate);
          if (articleDate < startDate) return false;
        }
        
        if (cbsFilters.endDate) {
          const endDate = new Date(cbsFilters.endDate);
          if (articleDate > endDate) return false;
        }
        
        return true;
      });
    }

    if (cbsFilters.sortBy === "newest") {
      filteredCbsArticles = [...filteredCbsArticles].sort((a, b) => 
        new Date(b.date.split(' ').reverse().join('-')).getTime() - 
        new Date(a.date.split(' ').reverse().join('-')).getTime()
      );
    } else if (cbsFilters.sortBy === "oldest") {
      filteredCbsArticles = [...filteredCbsArticles].sort((a, b) => 
        new Date(a.date.split(' ').reverse().join('-')).getTime() - 
        new Date(b.date.split(' ').reverse().join('-')).getTime()
      );
    }
  }

  // Filter media articles
  let filteredMediaArticles = mediaArticles;
  if (mediaSearchQuery.trim()) {
    filteredMediaArticles = filteredMediaArticles.filter((article) =>
      article.title.toLowerCase().includes(mediaSearchQuery.toLowerCase()) ||
      article.source.toLowerCase().includes(mediaSearchQuery.toLowerCase()) ||
      article.cbsArticle.toLowerCase().includes(mediaSearchQuery.toLowerCase())
    );
  }

  // Apply filters to media articles
  if (mediaFilters) {
    const hasSourceTypeFilter = mediaFilters.sourceTypes.print || mediaFilters.sourceTypes.online || mediaFilters.sourceTypes.rtv;
    const hasSourceFilter = Object.values(mediaFilters.sources).some(v => v);
    
    if (hasSourceTypeFilter || hasSourceFilter) {
      filteredMediaArticles = filteredMediaArticles.filter((article) => {
        // Check source types
        if (hasSourceTypeFilter) {
          const matchesSourceType = 
            (mediaFilters.sourceTypes.print && article.sourceType === "print") ||
            (mediaFilters.sourceTypes.online && article.sourceType === "online") ||
            (mediaFilters.sourceTypes.rtv && article.sourceType === "rtv");
          
          if (!matchesSourceType) return false;
        }
        
        // Check specific sources
        if (hasSourceFilter) {
          const matchesSource = mediaFilters.sources[article.source as keyof typeof mediaFilters.sources];
          if (!matchesSource) return false;
        }
        
        return true;
      });
    }

    // Apply date filters
    if (mediaFilters.startDate || mediaFilters.endDate) {
      filteredMediaArticles = filteredMediaArticles.filter((article) => {
        // Parse article date (format: "22 nov 2025")
        const dateParts = article.date.split(' ');
        const months: { [key: string]: string } = {
          'jan': '01', 'feb': '02', 'mrt': '03', 'apr': '04', 'mei': '05', 'jun': '06',
          'jul': '07', 'aug': '08', 'sep': '09', 'okt': '10', 'nov': '11', 'dec': '12'
        };
        const month = months[dateParts[1]];
        const articleDate = new Date(`${dateParts[2]}-${month}-${dateParts[0]}`);
        
        if (mediaFilters.startDate) {
          const startDate = new Date(mediaFilters.startDate);
          if (articleDate < startDate) return false;
        }
        
        if (mediaFilters.endDate) {
          const endDate = new Date(mediaFilters.endDate);
          if (articleDate > endDate) return false;
        }
        
        return true;
      });
    }

    if (mediaFilters.sortBy === "newest") {
      filteredMediaArticles = [...filteredMediaArticles].sort((a, b) => 
        new Date(b.date.split(' ').reverse().join('-')).getTime() - 
        new Date(a.date.split(' ').reverse().join('-')).getTime()
      );
    } else if (mediaFilters.sortBy === "oldest") {
      filteredMediaArticles = [...filteredMediaArticles].sort((a, b) => 
        new Date(a.date.split(' ').reverse().join('-')).getTime() - 
        new Date(b.date.split(' ').reverse().join('-')).getTime()
      );
    }
  }

  const getCategoryColor = (category: string) => {
    if (category.includes("Arbeid")) return "var(--cbs-aqua)";
    if (category.includes("Economie")) return "var(--cbs-corporate-blue)";
    if (category.includes("Maatschappij")) return "var(--cbs-pink)";
    return "#666";
  };

  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className={`border-b sticky top-0 z-50 ${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white'}`}>
        <div className="max-w-[1200px] mx-auto px-8 py-3">
          {/* Top Row: Breadcrumb and Dark Mode Toggle */}
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Button
                onClick={onBack}
                variant="ghost"
                className={`p-1 h-auto ${isDarkMode ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`}
                title="Terug naar Dashboard"
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
              
              <div className="flex items-center">
                <Breadcrumb 
                  items={[
                    { label: "Dashboard", onClick: onBack },
                    { label: "Zoeken" },
                    { label: activeTab === "cbs" ? "CBS Artikelen" : "Media Artikelen" }
                  ]}
                  isDarkMode={isDarkMode}
                />
              </div>
            </div>
            
            {onToggleDarkMode && (
              <button
                onClick={onToggleDarkMode}
                className="px-4 py-2 h-auto text-sm transition-all flex-shrink-0 rounded text-white inline-flex items-center justify-center"
                style={{ backgroundColor: 'var(--cbs-aqua)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#005470';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--cbs-aqua)';
                }}
              >
                {isDarkMode ? (
                  <Sun className="w-4 h-4" />
                ) : (
                  <Moon className="w-4 h-4" />
                )}
              </button>
            )}
          </div>
          
          {/* Bottom Row: Search Bar and Controls */}
          <div className="flex gap-3 items-center">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder={activeTab === "cbs" ? "Zoek CBS artikelen..." : "Zoek media artikelen..."}
                value={activeTab === "cbs" ? cbsSearchQuery : mediaSearchQuery}
                onChange={(e) => activeTab === "cbs" ? setCbsSearchQuery(e.target.value) : setMediaSearchQuery(e.target.value)}
                className={`w-full pl-9 pr-4 py-2 text-sm border rounded focus:outline-none focus:ring-2 focus:ring-[var(--cbs-aqua)] focus:border-transparent ${
                  isDarkMode ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400' : 'border-gray-300'
                }`}
              />
            </div>
            
            <Button
              onClick={() => setFilterSidebarOpen(true)}
              className="px-4 py-2 h-auto text-sm transition-all flex-shrink-0"
              style={{ backgroundColor: 'var(--cbs-aqua)' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#005470';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--cbs-aqua)';
              }}
            >
              <SlidersHorizontal className="w-4 h-4 mr-2" />
              Filters
            </Button>
            
            {/* Tabs - Right of Filter Button */}
            <Tabs value={activeTab} onValueChange={(value) => {
              setActiveTab(value as "cbs" | "media");
              if (onTabChange) onTabChange(value as "cbs" | "media");
            }}>
              <TabsList className={`mb-0 flex-shrink-0 ${isDarkMode ? 'bg-gray-700 border-gray-600' : ''}`}>
                <TabsTrigger value="cbs" className="text-sm px-4 py-1">CBS</TabsTrigger>
                <TabsTrigger value="media" className="text-sm px-4 py-1">Media</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-[1200px] mx-auto px-8 py-6">
        <Tabs value={activeTab}>
          {/* CBS Articles Tab */}
          <TabsContent value="cbs">
            {/* Results Count */}
            <div className="mb-4">
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {filteredCbsArticles.length} resultaten gevonden
              </p>
            </div>

            {/* Results */}
            {filteredCbsArticles.length === 0 ? (
              <Card className={`p-8 text-center ${isDarkMode ? 'bg-gray-800 border-gray-700' : ''}`}>
                <p className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>Geen CBS artikelen gevonden.</p>
                <p className={`text-sm mt-2 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                  Probeer andere zoektermen of pas uw filters aan.
                </p>
              </Card>
            ) : (
              <div className="space-y-2">
                {filteredCbsArticles.map((article) => (
                  <Card key={article.id} className={`p-4 hover:shadow-md transition-shadow ${isDarkMode ? 'bg-gray-800 border-gray-700' : ''}`}>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span
                            className="text-xs px-2 py-0.5 rounded"
                            style={{
                              backgroundColor: getCategoryColor(article.category),
                              color: 'white',
                            }}
                          >
                            {article.category}
                          </span>
                          <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{article.date}</span>
                        </div>
                        
                        <h3 
                          onClick={() => onCbsArticleClick?.(article)}
                          className={`mb-1 cursor-pointer hover:underline text-base ${isDarkMode ? 'text-[#4db3d3]' : ''}`} 
                          style={!isDarkMode ? { color: 'var(--cbs-aqua)' } : {}}
                        >
                          {article.title}
                        </h3>
                        
                        {article.summary && (
                          <p className={`text-sm line-clamp-2 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>{article.summary}</p>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Media Articles Tab */}
          <TabsContent value="media">
            {/* Results Count */}
            <div className="mb-4">
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {filteredMediaArticles.length} resultaten gevonden
              </p>
            </div>

            {/* Results */}
            {filteredMediaArticles.length === 0 ? (
              <Card className={`p-8 text-center ${isDarkMode ? 'bg-gray-800 border-gray-700' : ''}`}>
                <p className={isDarkMode ? 'text-gray-400' : 'text-gray-500'}>Geen media artikelen gevonden.</p>
                <p className={`text-sm mt-2 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                  Probeer andere zoektermen of pas uw filters aan.
                </p>
              </Card>
            ) : (
              <div className="space-y-2">
                {filteredMediaArticles.map((article) => (
                  <Card key={article.id} className={`p-4 hover:shadow-md transition-shadow ${isDarkMode ? 'bg-gray-800 border-gray-700' : ''}`}>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`text-sm ${isDarkMode ? 'text-[#6b9bd1]' : ''}`} style={!isDarkMode ? { color: 'var(--cbs-corporate-blue)' } : {}}>
                            {article.source}
                          </span>
                          <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{article.date}</span>
                        </div>
                        
                        <h3 
                          onClick={() => onMediaArticleClick?.(article)}
                          className={`mb-1 cursor-pointer hover:underline text-base ${isDarkMode ? 'text-[#4db3d3]' : ''}`} 
                          style={!isDarkMode ? { color: 'var(--cbs-aqua)' } : {}}
                        >
                          {article.title}
                        </h3>
                        
                        <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          Citeert CBS artikel: <span className="italic">{article.cbsArticle}</span>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Filter Sidebar */}
      <FilterSidebar 
        open={filterSidebarOpen}
        onClose={() => setFilterSidebarOpen(false)}
        onApplyFilters={handleApplyCbsFilters}
        mode={activeTab}
        isDarkMode={isDarkMode}
      />
    </div>
  );
}